# ThePantryApp

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 7.3.1.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Running server

Run `npm run dev` to launch the server (mongod.exe must be running and will require a new command window).

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).


##Sever Info
1. run `forever stopall` in the server folder in order to stop all node servers currently live.

2. Run `forever start index.js` in the server folder in order to start the server.

~ for debuging use `forever logs` in order to receive the log file locations for the current node sessions.


##Documentation
1. Check the documentation folder and open the index.html for documentation information. Generated using compodoc.

###Access to github
1. Email glennn@mail.gvsu.edu for access to the github.



require('require-dir')('tasks');

exports.config = {
    specs: ['./tests/e2e/**/*_test.js'],
    baseUrl: 'http://localhost:3333/'
}

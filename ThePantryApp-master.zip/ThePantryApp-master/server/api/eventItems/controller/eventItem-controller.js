"use strict";

const EventItemDAO = require("../dao/eventItem-dao");

module.exports = class TodoController {
  static getAll(req, res) {
    EventItemDAO
        .getAll()
        .then(eventItems => res.status(200).json(eventItems))
        .catch(error => res.status(400).json(error));
  }

  static getItemByEventId(req, res) {
    EventItemDAO
        .getItemByEventId(req.params.id)
        .then(eventItem => res.status(200).json(eventItem))
        .catch(error => res.status(400).json(error));
  }

  static getEventsByDay(req, res) {
    EventItemDAO
        .getEventsByDay(req.params.eventDay)
        .then(eventItem => res.status(200).json(eventItem))
        .catch(error => res.status(400).json(error));
  }

  static getEventsByRange(req, res) {
    EventItemDAO
        .getEventsByRange(req.params.rangeStart, req.params.rangeEnd)
        .then(eventItems => res.status(200).json(eventItems))
        .catch(error => res.status(400).json(error));
  }

  static updateItemById(req, res) {
    EventItemDAO
        .updateItemById(req.params.id, req.body)
        .then(eventItem => res.status(200).json(eventItem))
        .catch(error => res.status(400).json(error));
  }

  static createEventItem(req, res) {
      let _eventItem = req.body;

      EventItemDAO
        .createEventItem(_eventItem)
        .then(eventItem => res.status(201).json(eventItem))
        .catch(error => res.status(400).json(error));
  }

  static deleteEventItem(req, res) {
    let _id = req.params.id;

    EventItemDAO
      .deleteEventItem(_id)
      .then(() => res.status(200).end())
      .catch(error => res.status(400).json(error));
  }
}

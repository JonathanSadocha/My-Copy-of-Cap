"use strict";

let mongoose = require("mongoose");
const Promise = require("bluebird");
const eventItemSchema = require("../model/eventItem-model");
const _ = require("lodash");
const nodemailer = require("nodemailer")

eventItemSchema.statics.getAll = () => {
    return new Promise((resolve, reject) => {
        EventItem.find().lean()
            .exec((err, eventItem) => {

              err ? reject(err)
                  : resolve(eventItem);
            });
    });
};

eventItemSchema.statics.getEventsByDay = (eventDay) => {
    return new Promise((resolve, reject) => {
        if (!eventDay) {
          return reject(new TypeError("Id is not defined."));
        }
        let _query = {eventId: {$regex:new RegExp("^"+eventDay+"\.*"), $options: "ms"}}
        EventItem.find(_query).lean()
            .exec((err, eventItem) => {
              err ? reject(err)
                  : resolve(eventItem);
            });
    });
}

eventItemSchema.statics.getEventsByRange = (rangeStart,rangeEnd) => {
    return new Promise((resolve, reject) => {
        if (!rangeStart || !rangeEnd) {
          return reject(new TypeError("Id is not defined."));
        }
        let _query = {startDate: {$gt: new Date(rangeStart), $lt: new Date(rangeEnd)}}
        EventItem.find(_query).lean()
            .exec((err, eventItem) => {
              err ? reject(err)
                  : resolve(eventItem);
            });
    });
}

eventItemSchema.statics.sendOneDayReminder = (user, role) =>{
    return new Promise((resolve, reject)=>{
      const transporter = nodemailer.createTransport({
        name: 'thepantry.gr',
        host: 'mail.thepantry.gr',
        port: 465,
        secure: true,
        auth: {
          user: 'volunteer@thepantry.gr',
          pass: '?tGu1u2nN(#'
        }
      });  
      // const transporter = nodemailer.createTransport({
        //   host: 'smtp.ethereal.email',
        //   port: 587,
        //   auth: {
        //     user: 'gabe.mohr25@ethereal.email',
        //     pass: 'WQp574hyR8tf1VtPdA'
        //   }
        // });

        let htmlBody = '<html><head><title>The Pantry Event Reminder</title></head><body><div><h3>Thank You ' + user.firstName + ' ' + user.lastName + ' for signing up to volunteer tomorrow!</h3> <p>We look forward to seeing you on '+ role.startDate.toString()+'</p><br><p>See you soon!</p><br><p>The Pantry Team</p></div></body></html>'
        // setup email data with unicode symbols
        let mailOptions = {
          from: '"The Pantry" <Volunteer@thepantry.gr>', // sender address
          to: user.email, // list of receivers
          subject: "The Pantry Volunteer Reminder", // Subject line
          html: htmlBody // html body
        };

        // send mail with defined transport object
        transporter.sendMail(mailOptions)



          resolve('success');
    })
}


eventItemSchema.statics.sendAdminReminder = (users,admins, role, evtItem) =>{
  return new Promise((resolve, reject)=>{
      const transporter = nodemailer.createTransport({
        name: 'thepantry.gr',
        host: 'mail.thepantry.gr',
        port: 465,
        secure: true,
        auth: {
          user: 'volunteer@thepantry.gr',
          pass: '?tGu1u2nN(#'
        }
      });
      var vols = ''
      _.each(users, function(usr){
        vols += usr.firstName + ' '+ usr.lastName + ', ' ;
      })
      let htmlBody = '<html><head><title>The Pantry '+role.role +' volunteers for '+ evtItem.startDate.toString() +'</title></head><body><div><h2>' + role.role + ' volunteers for tomorrow:</h2></br><h5>The following individuals are signed up to volunteer tomorrow: ' + vols + '</h5></br> <p>At: '+ evtItem.startDate.toString()+ '</div></body></html>'
      // setup email data with unicode symbols
      let mailOptions = {
        from: '"The Pantry" <Volunteer@thepantry.gr>', // sender address
        to: admins, // list of receivers
        subject: "The Pantry Volunteer Reminder, " +role.role +"  "+ evtItem.startDate.toString(), // Subject line
        html: htmlBody // html bodyu
      };

      // send mail with defined transport object
      transporter.sendMail(mailOptions, function(error,info){
      })



        resolve('success');
  })
}

eventItemSchema.statics.getItemByEventId = (id) => {
    return new Promise((resolve, reject) => {
        if (!id) {
          return reject(new TypeError("Id is not defined."));
        }
        let _query = {eventId: id}
        EventItem.findOne(_query).lean()
            .exec((err, eventItem) => {
              err ? reject(err)
                  : resolve(eventItem);
            });
    });
}

eventItemSchema.statics.updateItemById = (id, eventItem) => {
    return new Promise((resolve, reject) => {
        if (!id) {
          return reject(new TypeError("Id is not defined."));
        }
        let _query = {_id: id}
        EventItem.findOneAndUpdate(_query, eventItem, {new:true}).lean()
            .exec((err, eventItem) => {
              err ? reject(err)
                  : resolve(eventItem);
            });
    });
}

eventItemSchema.statics.createEventItem = (eventItem) => {
    return new Promise((resolve, reject) => {
      if (!_.isObject(eventItem)) {
          return reject(new TypeError("eventItem is not a valid object."));
      }
      let m = new EventItem(eventItem)
      m.save((err, saved) => {
        err ? reject(err)
            : resolve(saved);
      })
    });
}

eventItemSchema.statics.deleteEventItem = (id) => {
    return new Promise((resolve, reject) => {
        if (!_.isString(id)) {
            return reject(new TypeError("Id is not a valid string."));
        }

        EventItem.findByIdAndRemove(id)
            .exec((err, deleted) => {
              err ? reject(err)
                  : resolve();
            });
    });
}

const EventItem  = mongoose.model("eventItems", eventItemSchema, "eventItems");

module.exports = EventItem;

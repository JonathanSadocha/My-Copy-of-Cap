"use strict";

const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const EventItem = {
    role:{type: Schema.Types.ObjectId, ref:'roles'},
    time:{type: String},
    eventId:{type: String},
    qty:{type: Number},
    startDate: {type: Date},
    endDate: {type: Date},
    volunteers: {type: Array}

}

module.exports = mongoose.Schema(EventItem, {versionKey: false, timestamps:{createdAt: 'created_at'}});

"use strict";

const EventItemController = require("../controller/eventItem-controller");

module.exports = class EventItemRoutes {
    static init(router) {
      router
      .route("/api/eventItems/new")
      .post(EventItemController.createEventItem)
      
      router
      .route("/api/eventItems/day/:eventDay")
      .get(EventItemController.getEventsByDay)

      router
        .route("/api/eventItems/:id")
        .get(EventItemController.getItemByEventId)
        .post(EventItemController.updateItemById)

        router
        .route("/api/eventItems/range/:rangeStart/:rangeEnd")
        .get(EventItemController.getEventsByRange)



      router
        .route("/api/role/delete/:id")
        .delete(EventItemController.deleteEventItem);
    }
}

"use strict";

let mongoose = require("mongoose");
const Promise = require("bluebird");
const eventSchema = require("../model/event-model");
const _ = require("lodash");
eventSchema.options.collection='events'

eventSchema.statics.getAll = () => {
    return new Promise((resolve, reject) => {
        let _query = {_id: '5c6ed4277971506ec430dbae'};
        console.log(eventSchema.options.collection)
        Events.find()
            .exec((err, events) => {
                var eventOut = {
                    results: events
                }
              err ? reject(err)
                  : resolve(eventOut);
            });
    });
};

eventSchema.statics.getById = (id) => {
    return new Promise((resolve, reject) => {
        if (!id) {
          return reject(new TypeError("Id is not defined."));
        }

        Events.findById(id)
            .exec((err, event) => {
              err ? reject(err)
                  : resolve(event);
            });
    });
}

eventSchema.statics.createEvent = (event) => {
    return new Promise((resolve, reject) => {
      if (!_.isObject(event)) {
          return reject(new TypeError("Event is not a valid object."));
      }

      let _event = new Events(event);

      _event.save((err, saved) => {
        err ? reject(err)
            : resolve(saved);
      });
    });
}

eventSchema.statics.deleteEvent = (id) => {
    return new Promise((resolve, reject) => {
        if (!_.isString(id)) {
            return reject(new TypeError("Id is not a valid string."));
        }

        Events.findByIdAndRemove(id)
            .exec((err, deleted) => {
              err ? reject(err)
                  : resolve();
            });
    });
}

const Events  = mongoose.model("Events", eventSchema);

module.exports = Events;

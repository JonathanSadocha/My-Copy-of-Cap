"use strict";

const mongoose = require("mongoose");

const Events = {
    startDate: {type: Date},
    endDate: {type: Date},
    frequency:{type: Object},
    jobs:{type: Array}
}

module.exports = mongoose.Schema(Events,{versionKey: false});

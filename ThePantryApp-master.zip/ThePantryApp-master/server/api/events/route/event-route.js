"use strict";

const EventsController = require("../controller/event-controller");

module.exports = class EventRoutes {
    static init(router) {
      router
        .route("/api/events/getAll")
        .get(EventsController.getAll)
        .post(EventsController.createEvent);

      router
        .route("/api/event/delete/:id")
        .delete(EventsController.deleteEvent);
    }
}

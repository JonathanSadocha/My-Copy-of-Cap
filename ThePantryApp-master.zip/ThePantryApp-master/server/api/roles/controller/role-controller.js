"use strict";

const RoleDAO = require("../dao/role-dao");

module.exports = class RoleController {
  static getAll(req, res) {
    RoleDAO
        .getAll()
        .then(roles => res.status(200).json(roles))
        .catch(error => res.status(400).json(error));
  }

  static getById(req, res) {
    RoleDAO
        .getById(req.params.id)
        .then(role => res.status(200).json(role))
        .catch(error => res.status(400).json(error));
  }

  static createRole(req, res) {
      let _role = req.body;

      RoleDAO
        .createRole(_role)
        .then(role => res.status(201).json(role))
        .catch(error => res.status(400).json(error));
  }

  static updateRole(req, res) {
    let _role = req.body;

    RoleDAO
      .updateRole(_role)
      .then(role => res.status(201).json(role))
      .catch(error => res.status(400).json(error));
}

  static deleteRole(req, res) {
    let _id = req.params.id;

    RoleDAO
      .deleteRole(_id)
      .then(() => res.status(200).end())
      .catch(error => res.status(400).json(error));
  }
}

"use strict";

let mongoose = require("mongoose");
const Promise = require("bluebird");
const roleSchema = require("../model/role-model");
const _ = require("lodash");
roleSchema.options.collection='roles'

roleSchema.statics.getAll = () => {
    return new Promise((resolve, reject) => {
        Roles.find()
            .exec((err, roles) => {

              err ? reject(err)
                  : resolve(roles);
            });
    });
};

roleSchema.statics.getById = (id) => {
    return new Promise((resolve, reject) => {
        if (!id) {
          return reject(new TypeError("Id is not defined."));
        }

        Roles.findById(id)
            .exec((err, role) => {
              err ? reject(err)
                  : resolve(role);
            });
    });
}

//creates a new role in the db
roleSchema.statics.createRole = (role) => {
    return new Promise((resolve, reject) => {
      if (!_.isObject(role)) {
          return reject(new TypeError("Role is not a valid object."));
      }

      let _role = new Roles(role);

      _role.save((err, saved) => {
        err ? reject(err)
            : resolve(saved);
      });
    });
}

// updates the role in the db
roleSchema.statics.updateRole = (role) => {
    return new Promise((resolve, reject) => {
      if (!_.isObject(role)) {
          return reject(new TypeError("Role is not a valid object."));
      }

      let _query = {_id: role._id}
      Roles.findOneAndUpdate(_query, role)
        .exec((err, saved) => {
            err ? reject(err)
                : resolve(saved);
        });
    });
}

//removes the role from the db
roleSchema.statics.deleteRole = (id) => {
    return new Promise((resolve, reject) => {
        if (!_.isString(id)) {
            return reject(new TypeError("Id is not a valid string."));
        }

        Roles.findByIdAndRemove(id)
            .exec((err, deleted) => {
              err ? reject(err)
                  : resolve();
            });
    });
}

const Roles  = mongoose.model("roles", roleSchema, "roles");

module.exports = Roles;

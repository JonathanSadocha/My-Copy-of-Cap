"use strict";

const mongoose = require("mongoose");

const Roles = {
    role:{type: String},
    time:{type: String},
    qty:{type: Number},
    description:{type:String},
    startDate: {type: Date},
    endDate: {type: Date},
    days:{type: Object},

}

module.exports = mongoose.Schema(Roles, {versionKey: false, strict: false});

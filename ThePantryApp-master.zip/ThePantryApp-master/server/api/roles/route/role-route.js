"use strict";

const RoleController = require("../controller/role-controller");

module.exports = class RoleRoutes {
    static init(router) {
      router
        .route("/api/roles/getAll")
        .get(RoleController.getAll)

      router
        .route("/api/roles/get/:id")
        .get(RoleController.getById)

      router
        .route("/api/roles/update")
        .post(RoleController.updateRole)

        router
        .route("/api/roles/create")
        .post(RoleController.createRole)

      router
        .route("/api/role/delete/:id")
        .delete(RoleController.deleteRole);
    }
}

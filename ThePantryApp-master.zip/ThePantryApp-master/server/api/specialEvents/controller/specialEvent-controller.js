"use strict";

const SpecialEventDAO = require("../dao/specialEvent-dao");

module.exports = class SpecialEventController {
  static getAll(req, res) {
    SpecialEventDAO
        .getAll()
        .then(specialEvents => res.status(200).json(specialEvents))
        .catch(error => res.status(400).json(error));
  }

  static getById(req, res) {
    SpecialEventDAO
        .getById(req.params.id)
        .then(special => res.status(200).json(special))
        .catch(error => res.status(400).json(error));
  }
 
  static createSpecialEvent(req, res) {
      let _special = req.body;

      SpecialEventDAO
        .createSpecialEvent(_special)
        .then(special => res.status(201).json(special))
        .catch(error => res.status(400).json(error));
  }

  static getEventsByRange(req, res) {
    SpecialEventDAO
        .getEventsByRange(req.params.rangeStart, req.params.rangeEnd)
        .then(specialEvents => res.status(200).json(specialEvents))
        .catch(error => res.status(400).json(error));
  }

  static updateSpecialEvent(req, res) {
    let _special = req.body;

    SpecialEventDAO
      .updateSpecialEvent(_special)
      .then(special => res.status(201).json(special))
      .catch(error => res.status(400).json(error));
}

  static deleteSpecialEvent(req, res) {
    let _id = req.params.id;

    SpecialEventDAO
      .deleteSpecialEvent(_id)
      .then(() => res.status(200).json('success'))
      .catch(error => res.status(400).json(error));
  }
}

"use strict";

let mongoose = require("mongoose");
const Promise = require("bluebird");
const specialSchema = require("../model/specialEvent-model");
const _ = require("lodash");
specialSchema.options.collection='specialEvents'

specialSchema.statics.getAll = () => {
    return new Promise((resolve, reject) => {
        SpecialEvents.find()
            .exec((err, specials) => {

              err ? reject(err)
                  : resolve(specials);
            });
    });
};

specialSchema.statics.getById = (id) => {
    return new Promise((resolve, reject) => {
        if (!id) {
          return reject(new TypeError("Id is not defined."));
        }

        SpecialEvents.findById(id)
            .exec((err, special) => {
              err ? reject(err)
                  : resolve(special);
            });
    });
}

specialSchema.statics.getEventsByRange = (rangeStart,rangeEnd) => {
    return new Promise((resolve, reject) => {
        if (!rangeStart || !rangeEnd) {
          return reject(new TypeError("Id is not defined."));
        }
        let _query = {startDate: {$gt: new Date(rangeStart), $lt: new Date(rangeEnd)}}
        SpecialEvents.find(_query).lean()
            .exec((err, eventItem) => {
              err ? reject(err)
                  : resolve(eventItem);
            });
    });
}

specialSchema.statics.createSpecialEvent = (special) => {
    return new Promise((resolve, reject) => {
      if (!_.isObject(special)) {
          return reject(new TypeError("Special Event is not a valid object."));
      }

      let _special = new SpecialEvents(special);

      _special.save((err, saved) => {
        err ? reject(err)
            : resolve(saved);
      });
    });
}

specialSchema.statics.updateSpecialEvent = (special) => {
    return new Promise((resolve, reject) => {
      if (!_.isObject(special)) {
          return reject(new TypeError("Special Event is not a valid object."));
      }

      let _query = {_id: special._id}
      SpecialEvents.findOneAndUpdate(_query, special)
        .exec((err, saved) => {
            console.log(saved)
            console.log(err)
            err ? reject(err)
                : resolve(saved);
        });
    });
}

specialSchema.statics.deleteSpecialEvent = (id) => {
    return new Promise((resolve, reject) => {
        if (!_.isString(id)) {
            return reject(new TypeError("Id is not a valid string."));
        }

        SpecialEvents.findByIdAndRemove(id)
            .exec((err, deleted) => {
              err ? reject(err)
                  : resolve();
            });
    });
}

const SpecialEvents  = mongoose.model("specialEvents", specialSchema, "specialEvents");

module.exports = SpecialEvents;

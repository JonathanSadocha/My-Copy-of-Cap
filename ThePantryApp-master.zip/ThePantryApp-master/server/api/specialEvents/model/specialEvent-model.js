"use strict";

const mongoose = require("mongoose");

const SpecialEvents = {
    title:{type: String},
    description: {type: String},
    volunteersNeeded:{type: Number},
    volunteers: {type: Array},
    startTime:{type: Date},
    endTime:{type: Date},
    startDate: {type: Date},
    endDate: {type: Date},
    
}

module.exports = mongoose.Schema(SpecialEvents, {versionKey: false,timestamps:{createdAt: 'created_at'}});

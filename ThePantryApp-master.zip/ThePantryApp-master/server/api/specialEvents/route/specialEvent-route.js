"use strict";

const SpecialEventController = require("../controller/specialEvent-controller");

module.exports = class SpecialEventRoutes {
    static init(router) {
      router
        .route("/api/specialEvent/getAll")
        .get(SpecialEventController.getAll)

      router
        .route("/api/specialEvent/get/:id")
        .get(SpecialEventController.getById)

        router
        .route("/api/specialEvent/range/get/:rangeStart/:rangeEnd")
        .get(SpecialEventController.getEventsByRange)

      router
        .route("/api/specialEvent/update")
        .post(SpecialEventController.updateSpecialEvent)

        router
        .route("/api/specialEvent/create")
        .post(SpecialEventController.createSpecialEvent)

      router
        .route("/api/specialEvent/delete/:id")
        .delete(SpecialEventController.deleteSpecialEvent);
    }
}

"use strict";

const GuestDAO = require("../dao/guest-dao");

module.exports = class GuestController {

  static getGuestByEmail(req, res) {
    GuestDAO
        .getGuestByEmail(req.params.id)
        .then(guest => res.status(200).json(guest))
        .catch(error => res.status(400).json(error));
  }

  static getAll(req, res) {
    GuestDAO
        .getAll()
        .then(guest => res.status(200).json(guest))
        .catch(error => res.status(400).json(error));
  }

  static newGuest(req, res) {
      let _guest = req.body;
      GuestDAO
        .newGuest(_guest)
        .then(guest => res.status(201).json(guest))
        .catch(error => res.status(400).json(error));
  }

  static getExcelFileName(req, res) {
    GuestDAO
      .getExcelFileName()
      .then(guest => res.status(200).json(guest))
      .catch(error => res.status(400).json(error));
  }

  static downloadGuestReport(req,res){
    res.download('./data/guests/'+req.params.filepath, function(err){
      if(err){
        console.log(err)
      }else{
      }
    })
  }

  static deleteGuest(req, res) {
    let _id = req.params.id;

    GuestDAO
      .deleteGuest(_id)
      .then(() => res.status(200).end())
      .catch(error => res.status(400).json(error));
  }
}

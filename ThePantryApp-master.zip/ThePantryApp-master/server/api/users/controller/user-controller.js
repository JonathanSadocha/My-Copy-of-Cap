"use strict";

const UserDAO = require("../dao/user-dao");
const bcrypt = require('bcrypt');

module.exports = class UserController {
  static loginUser(req, res) {
    var _user = req.body;

    UserDAO
      .loginUser(_user)
      .then(user => {
        var firstLogin = false;
        if (user == {}) {
          res.status(200).json(null);
        } else if (user) {
          var userInfo = {
            _id: user._id,
            email: user.email,
            role: user.role,
            firstName: user.firstName,
            lastName: user.lastName,
            address: user.address,
            address2: user.address2,
            city: user.city,
            state: user.state,
            zip: user.zip,
            phone: user.phone,
            employer: user.employer,
            affiliation: user.affiliation,
            accommodations: user.accommodations,
            allergies: user.allergies,
            race: user.race,
            gender: user.gender,
            emgContactFName: user.emgContactFName,
            emgContactLName: user.emgContactLName,
            emgContactPhone: user.emgContactPhone,
            activeAccount: user.activeAccount
          }
          bcrypt.compare(_user.password, user.password, function (err, result) {
            if (result == true) {
              res.status(200).json(userInfo);
            } else {
              res.status(200).json(null);
            }
          })
        } else if (err) {
          res.status(200).json(null);
        }
      })
      .catch(error => res.status(200).json(null));


  }


  static resetPassword(req, res) {
    var _email = req.params.email;

    UserDAO
      .checkEmail(_email)
      .then(user => {
        if (user == null) {
          res.status(200).json(null);
        } else if (user) {
          var userHold ={
            _id: user._id,
            email: _email,
            password: ''
          }
          UserDAO.sendPasswordReset(userHold)
            .then(userUpdate =>{
              if(userUpdate == 'success'){
                res.status(200).json('success')
              }
              else{
                res.status(200).json(null)
              }
            })

          
        } else if (err) {
          res.status(200).json(null);
        }
        else{
          res.status(200).json(null);
        }
      })
      .catch(error => res.status(200).json(null));


  }

  static getUserById(req, res) {
    UserDAO
      .getUserById(req.params.id)
      .then(user => res.status(200).json(user))
      .catch(error => res.status(400).json(error));
  }

  
  static getAll(req, res) {
    UserDAO
      .getAll()
      .then(user => res.status(200).json(user))
      .catch(error => res.status(400).json(error));
  }

  
  static getByToken(req, res) {
    UserDAO
      .getByToken(req.params.token)
      .then(user => res.status(200).json(user))
      .catch(error => res.status(400).json(error));
  }

  static checkEmail(req, res) {
    UserDAO
      .checkEmail(req.params.email)
      .then(user => res.status(200).json(user))
      .catch(error => res.status(400).json(error));
  }

  static createUser(req, res) {
    let _user = req.body;

    UserDAO
      .createUser(_user)
      .then(user => res.status(201).json(user))
      .catch(error => res.status(400).json(error));
  }

  static createManuallyUser(req, res) {
    let _user = req.body;

    UserDAO
      .createManuallyUser(_user)
      .then(user => res.status(201).json(user))
      .catch(error => res.status(400).json(error));
  }


  static updateUser(req, res) {
    let _user = req.body;

    UserDAO
      .updateUser(_user)
      .then(user => res.status(201).json(user))
      .catch(error => res.status(400).json(error));
  }

  
  static updateUserPassword(req, res) {
    let _user = req.body;

    UserDAO
      .updateUserPassword(_user)
      .then(user => res.status(201).json(user))
      .catch(error => res.status(400).json(error));
  }



  static getExcelFile(req, res) {
    UserDAO
      .getExelFile()
      .then(user => res.status(201).json(user))
      .catch(error => res.status(400).json(error));
  }

  static downloadUserReport(req,res){
    res.download('./data/users/'+req.params.filepath, function(err){
      if(err){
        console.log(err)
      }else{
      }
    })
  }


  static deleteUser(req, res) {
    let _id = req.params.id;

    UserDAO
      .deleteUser(_id)
      .then(() => res.status(200).end())
      .catch(error => res.status(400).json(error));
  }
}

"use strict";

let mongoose = require("mongoose");
const Promise = require("bluebird");
const guestSchema = require("../model/guest-model");
const _ = require("lodash");
const mongoXlsx = require('mongo-xlsx');


guestSchema.statics.getGuestByEmail = (id) => {
    return new Promise((resolve, reject) => {
        if (!id) {
          return reject(new TypeError("Id is not defined."));
        }
        let _query = {eventId: id}
        Guests.find(_query)
            .exec((err, guest) => {
              err ? reject(err)
                  : resolve(guest);
            });
    });
}

guestSchema.statics.getAll = () => {
  return new Promise((resolve, reject) => {
      Guests.find().lean()
          .exec((err, guests) => {

            err ? reject(err)
                : resolve(guests);
          });
  });
}


guestSchema.statics.getExcelFileName = () => {
    return new Promise((resolve, reject) => {
      Guests.find({})
        .exec((err, usersOut) => {
          var userModel = mongoXlsx.buildDynamicModel(usersOut)
          _.each(userModel, function(itm){
            if(itm['displayName'] == 'created_at' || itm['displayName'] == 'updatedAt'){
                itm['type'] = 'string'
            }
          })

          var dateHold = new Date()
          dateHold = dateHold.toDateString()
          dateHold = dateHold.replace(/\s/g, '-');
          mongoXlsx.mongoData2Xlsx(usersOut, userModel,{'fileName': 'Pantry-Guests-'+dateHold+'.xlsx', 'path': 'data/guests'}, function(err,data){
            console.log('File saved at:', data.fullPath)
            err ? reject(err) :
            resolve(data);
          })
  
        });
    });
  }



guestSchema.statics.newGuest = (guest) => {
    return new Promise((resolve, reject) => {
      if (!_.isObject(guest)) {
          return reject(new TypeError("guest is not a valid object."));
      }
      var _query = {email:guest.email, firstName: guest.firstName, lastName: guest.lastName}
        Guests.findOneAndUpdate(_query, guest, {new: true, upsert: true}).exec((err, saved) => {
          err ? reject(err)
              : resolve(saved);
        });


    });
}

guestSchema.statics.getGuestById = (id) => {
  return new Promise((resolve, reject) => {
    if (!id) {
      return reject(new TypeError("Id is not defined."));
    }
    let _query = {
      _id: id
    }
    Guests.find(_query)
      .exec((err, guest) => {
        err ? reject(err) :
          resolve(guest);
      });
  });
}



guestSchema.statics.deleteGuest = (id) => {
    return new Promise((resolve, reject) => {
        if (!_.isString(id)) {
            return reject(new TypeError("Id is not a valid string."));
        }

        Guests.findByIdAndRemove(id)
            .exec((err, deleted) => {
              err ? reject(err)
                  : resolve();
            });
    });
}

const Guests  = mongoose.model("guests", guestSchema, "guests");

module.exports = Guests;

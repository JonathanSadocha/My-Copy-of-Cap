"use strict";

let mongoose = require("mongoose");
const Promise = require("bluebird");
const userSchema = require("../model/user-model");
const _ = require("lodash");
const bcrypt = require('bcrypt');
const saltRounds = 10;
const mongoXlsx = require('mongo-xlsx');
const nodemailer = require("nodemailer");
const crypto = require('crypto');


userSchema.statics.loginUser = (userInput) => {
  return new Promise((resolve, reject) => {
    let _query = {
      email: userInput.email
    }
    Users.findOne(_query)
      .exec((err, user) => {
        err ? reject(err) :
          resolve(user)

      });
  });
};

userSchema.statics.getUserById = (id) => {
  return new Promise((resolve, reject) => {
    if (!id) {
      return reject(new TypeError("Id is not defined."));
    }
    let _query = {
      _id: id
    }
    Users.find(_query, '-password')
      .exec((err, user) => {
        err ? reject(err) :
          resolve(user);
      });
  });
}

userSchema.statics.getAdminEmails = () => {
  return new Promise((resolve, reject) => {
    let _query = {
      role: 'admin'
    }
    Users.find(_query)
      .exec((err, user) => {
        var admStr = ''
        _.each(user, admin=>{
          admStr += admin.email + ','
        })
        err ? reject(err) :
          resolve(admStr);
      });
  });
}

userSchema.statics.getAll = () => {
  return new Promise((resolve, reject) => {
      Users.find().lean()
          .exec((err, users) => {

            err ? reject(err)
                : resolve(users);
          });
  });
};

userSchema.statics.getByToken = (token) => {
  return new Promise((resolve, reject) => {
    if (!token) {
      return reject(new TypeError("token is not defined."));
    }
    let _query = {
      password: token
    }
    Users.find(_query, )
      .exec((err, user) => {
        err ? reject(err) :
          resolve(user);
      });
  });
}


userSchema.statics.getExelFile = () => {
  return new Promise((resolve, reject) => {
    Users.find({}, '-password')
      .exec((err, usersOut) => {

        var userModel = mongoXlsx.buildDynamicModel(usersOut)
        _.each(userModel, function (itm) {
          if (itm['displayName'] == 'created_at' || itm['displayName'] == 'updatedAt') {
            itm['type'] = 'string'
          }
        })
        
        var dateHold = new Date()
        dateHold = dateHold.toDateString()
        dateHold = dateHold.replace(/\s/g, '-');
        mongoXlsx.mongoData2Xlsx(usersOut, userModel, {
          'fileName': 'Pantry-Users-' + dateHold + '.xlsx',
          'path': 'data/users'
        }, function (err, data) {
          console.log('File saved at:', data.fullPath)
          err ? reject(err) :
            resolve(data);
        })

      });
  });
}

userSchema.statics.checkEmail = (emailInput) => {
  return new Promise((resolve, reject) => {
    if (!emailInput) {
      return reject(new TypeError("email is not defined."));
    }
    let _query = {
      email: emailInput
    }
    //checks to see if an email already has that email address
    Users.findOne(_query, 'email ')
      .exec((err, user) => {
        err ? reject(err) :
          resolve(user);
      });
  });
}

userSchema.statics.createUser = (user) => {
  return new Promise((resolve, reject) => {
    if (!_.isObject(user)) {
      return reject(new TypeError("user is not a valid object."));
    }
    bcrypt.genSalt(8, function (err, salt) {
      bcrypt.hash(user.password, salt, function (err, hash) {
        // Creates the encrypted password
        if (hash) {
          user.password = hash
          let _user = new Users(user);
          _user.save((err, saved) => {
            err ? reject(err) :
              resolve(saved);
          });
        }
      });
    })


  });
}

userSchema.statics.createManuallyUser = (user) => {
  return new Promise((resolve, reject) => {
    if (!_.isObject(user)) {
      return reject(new TypeError("user is not a valid object."));
    }
    crypto.randomBytes(20, function (err, buffer) {
      var token = buffer.toString('hex');
      user.password = token
      let _user = new Users(user);
      _user.save((err, saved) => {
        let url = 'http://volunteer.thepantry.gr/user/reset/password/' + token
        // let url = 'http://localhost:4200/user/reset/password/' + token
        // const transporter = nodemailer.createTransport({
        //   host: 'smtp.ethereal.email',
        //   port: 587,
        //   auth: {
        //     user: 'gabe.mohr25@ethereal.email',
        //     pass: 'WQp574hyR8tf1VtPdA'
        //   }
        // });
       
        const transporter = nodemailer.createTransport({
          name: 'thepantry.gr',
          host: 'mail.thepantry.gr',
          port: 465,
          secure: true,
          auth: {
            user: 'volunteer@thepantry.gr',
            pass: '?tGu1u2nN(#'
          }
        });

        let htmlBody = '<html><head><title>The Pantry Account Registration</title></head><body><div><h3>Welcome to the volunteer system ' + user.firstName + ' ' + user.lastName + '!</h3> <p>In order to activate your account, kindly use this <a href="' + url + '">link</a></p><br><p>See you soon!</p><br><p>The Pantry Team</p></div></body></html>'
        console.log(htmlBody)
        // setup email data with unicode symbols
        let mailOptions = {
          from: '"The Pantry" <volunteer@thepantry.gr>', // sender address
          to: user.email, // list of receivers
          subject: "The Pantry Account Activation Information", // Subject line
          html: htmlBody // html body
        };

        // send mail with defined transport object
        transporter.sendMail(mailOptions)



        err ? reject(err) :
          resolve('success');
      });
    })



  });
}





userSchema.statics.updateUser = (user) => {
  return new Promise((resolve, reject) => {
    if (!_.isObject(user)) {
      return reject(new TypeError("user is not a valid object."));
    }
    let _query = {
      _id: user._id
    }
          Users.findOneAndUpdate(_query, user).lean().exec((err, saved) => {
            err ? reject(err) :
              resolve(saved);
          });
  });
}

userSchema.statics.updateUserPassword = (user) => {
  return new Promise((resolve, reject) => {
    if (!_.isObject(user)) {
      return reject(new TypeError("user is not a valid object."));
    }
    let _query = {
      _id: user._id
    }
    bcrypt.genSalt(8, function (err, salt) {
      bcrypt.hash(user.password, salt, function (err, hash) {
        // Creates the encrypted password
        if (hash) {
          user.password = hash
          console.log(user)
          Users.findOneAndUpdate(_query, user).lean().exec((err, saved) => {
            err ? reject(err) :
              resolve(saved);
          });
        }
      })
    })
  });
}


userSchema.statics.sendPasswordReset = (user) => {
  return new Promise((resolve, reject) => {
    if (!_.isObject(user)) {
      return reject(new TypeError("user is not a valid object."));
    }
    crypto.randomBytes(20, function (err, buffer) {
      var token = buffer.toString('hex');
      user.password = token
      let _query = {_id: user._id}
      Users.findOneAndUpdate(_query, user).lean().exec((err, saved) => {
        // let url = 'http://localhost:4200/user/reset/password/' + token
        let url = 'http://volunteer.thepantry.gr/user/reset/password/' + token

        //need to create an email account for the mailer in order to properly send mail
        // const transporter = nodemailer.createTransport({
        //   host: 'smtp.ethereal.email',
        //   port: 587,
        //   auth: {
        //     user: 'gabe.mohr25@ethereal.email',
        //     pass: 'WQp574hyR8tf1VtPdA'
        //   }
        // });

        const transporter = nodemailer.createTransport({
          name: 'thepantry.gr',
          host: 'mail.thepantry.gr',
          port: 465,
          secure: true,
          auth: {
            user: 'volunteer@thepantry.gr',
            pass: '?tGu1u2nN(#'
          }
        });
        let htmlBody = '<html><head><title>The Pantry Account Password Reset</title></head><body><div><h3>You have requested a password reset ' + saved.firstName + ' ' + saved.lastName + '!</h3> <p>Follow this link in order to reset your password! <a href="' + url + '">link</a></p><br><p>See you soon!</p><br><p>The Pantry Team</p></div></body></html>'
        // setup email data with unicode symbols
        let mailOptions = {
          from: '"The Pantry" <volunteer@thepantry.gr>', // sender address
          to: user.email, // list of receivers
          subject: "The Pantry Password Reset Information", // Subject line
          html: htmlBody // html body
        };
        // send mail with defined transport object
        transporter.sendMail(mailOptions)
        err ? reject(err) :
          resolve('success');
      });
    })



  });
}

userSchema.statics.deleteUser = (id) => {
  return new Promise((resolve, reject) => {
    if (!_.isString(id)) {
      return reject(new TypeError("Id is not a valid string."));
    }

    Users.findByIdAndRemove(id)
      .exec((err, deleted) => {
        err ? reject(err) :
          resolve();
      });
  });
}

const Users = mongoose.model("users", userSchema, "users");

module.exports = Users;

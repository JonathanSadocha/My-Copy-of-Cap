"use strict";

const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const Guests = {
    firstName:{type:String},
    lastName:{type:String},
    email:{type:String},
    address:{type:String},
    address2:{type:String},
    city:{type:String},
    state:{type:String},
    zip:{type:String},
    phone:{type:String},
    employer:{type:String},
    affiliation:{type:String},
    accommodations:{type:String},
    allergies:{type:String},
    race:{type:String},
    gender:{type:String},
    emgContactFName:{type:String},
    emgContactLName:{type:String},
    emgContactPhone:{type:String},

}

module.exports = mongoose.Schema(Guests, {versionKey: false,  timestamps:{createdAt: 'created_at'}, strict: false});

"use strict";

const guestController = require("../controller/guest-controller");

module.exports = class GuestRoutes {
  static init(router) {

    router
      .route("/api/guest/new")
      .post(guestController.newGuest)

      router
      .route("/api/guest/all")
      .get(guestController.getAll)

    router
      .route("/api/guest/getExcelFile")
      .get(guestController.getExcelFileName)

    router
      .route("/api/guest/:id")
      .get(guestController.getGuestByEmail)


    router
      .route("/api/guest/delete/:id")
      .delete(guestController.deleteGuest);

    router
      .route("/static/data/guests/:filepath")
      .get(guestController.downloadGuestReport)

  }
}

"use strict";

const userController = require("../controller/user-controller");

module.exports = class UserRoutes {
  static init(router) {
    router
      .route("/api/user/login")
      .post(userController.loginUser)

    router
      .route("/api/user/getExcelFile")
      .get(userController.getExcelFile)

    router
      .route("/static/data/users/:filepath")
      .get(userController.downloadUserReport)

    router
      .route("/api/user/getAll")
      .get(userController.getAll)

    router
      .route("/api/user/check/:email")
      .get(userController.checkEmail)

    router
      .route("/api/user/update/:id")
      .post(userController.updateUser)

    router
      .route("/api/user/new")
      .post(userController.createUser)

    router
      .route("/api/user/reset/account/:email")
      .get(userController.resetPassword)


    router
      .route("/api/user/new/manual")
      .post(userController.createManuallyUser)

    router
      .route("/api/user/getByToken/:token")
      .get(userController.getByToken)

    router
      .route("/api/user/getbyid/:id")
      .get(userController.getUserById)

    router
      .route("/api/user/update/account/password")
      .post(userController.updateUserPassword)





  }
}

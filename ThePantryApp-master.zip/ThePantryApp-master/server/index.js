"use strict";

require('./server');

"use strict";

const EventRoutes = require("../api/events/route/event-route");
const RoleRoutes = require("../api/roles/route/role-route");
const EventItemRoutes = require("../api/eventItems/route/eventItem-route");
const UserRoutes = require("../api/users/route/user-route");
const GuestRoutes = require("../api/users/route/guest-route");
const SpecialEventRoutes = require("../api/specialEvents/route/specialEvent-route");


module.exports = class Routes {
   static init(app, router) {
     EventRoutes.init(router);
     RoleRoutes.init(router);
     EventItemRoutes.init(router);
     UserRoutes.init(router);
     GuestRoutes.init(router);
     SpecialEventRoutes.init(router);

    app.use(function(req,res,next){
      // res.header("Access-Control-Allow-Origin", "http://localhost:4200");
      res.header("Access-Control-Allow-Origin", "http://volunteer.thepantry.gr");
      res.header("Access-Control-Allow-Methods", "GET,PUT,POST,DELETE");
      res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
      next();
    })
     app.use("/", router);
   }
}

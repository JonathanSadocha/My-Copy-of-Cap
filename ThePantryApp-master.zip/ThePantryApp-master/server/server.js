"use strict";

const PORT = process.env.PORT || 3333;

const os = require("os");
const http = require("http");
const express = require("express");
const RoutesConfig = require("./config/routes.conf");
const DBConfig = require("./config/db.conf");
const Routes = require("./routes/index");
const cron = require("node-cron");
const moment = require("moment");
const EventItemDAO = require("./api/eventItems/dao/eventItem-dao");
const UserDAO = require("./api/users/dao/user-dao");
const GuestDAO = require("./api/users/dao/guest-dao");
const SpecialEventDAO = require("./api/specialEvents/dao/specialEvent-dao");
const RoleDAO = require("./api/roles/dao/role-dao");

const _ = require("lodash");

const app = express();


// cron.schedule('29 * * * *', () => {
  cron.schedule('0 8 * * 0,2,3,4', () => {
  var date1 = moment(new Date()).startOf('date');
  var date2 = moment(new Date()).add(1, 'days')
  date2 = date2.endOf('date')
  EventItemDAO.getEventsByRange(date1.toDate(), date2.toDate()).then(res => {
    //get the events whos days are in the next 24 hrs then send the volunteers an email
    if (res.length != 0) {
      _.each(res, item => {
        var volunteerArray = []
        if (item.volunteers) {
          var volCount = 0;
          _.each(item.volunteers, vol => {
            UserDAO.getUserById(vol).then(response => {
              if (response.length == 0) {
                GuestDAO.getGuestById(vol).then(gusetRes => {
                  if (gusetRes.length != 0) {
                    volunteerArray.push(gusetRes[0])
                    if (volunteerArray.length == item.volunteers.length) {
                      RoleDAO.getById(item.role).then(roleObj => {
                        UserDAO.getAdminEmails().then(response => {
                          EventItemDAO.sendAdminReminder(volunteerArray, response, roleObj, item).then(result => {})
                        }) 
                      })

                    }
                    EventItemDAO.sendOneDayReminder(gusetRes[0], item).then(result => {})
                  }
                })
              } else {
                volunteerArray.push(response[0])
                if (volunteerArray.length == item.volunteers.length) {
                  RoleDAO.getById(item.role).then(roleObj => {
                    UserDAO.getAdminEmails().then(response => {
                      EventItemDAO.sendAdminReminder(volunteerArray, response, roleObj, item).then(result => {})
                    })
                  })

                }
                EventItemDAO.sendOneDayReminder(response[0], item).then(result => {

                })
              }
            })
            volCount += 1;
          })
        }
      })
    }

  }).catch(err => {
    console.log(err)
  })


  //special event mailout
  SpecialEventDAO.getEventsByRange(date1.toDate(), date2.toDate()).then(res => {
    //get the events whos days are in the next 24 hrs then send the volunteers an email
    if (res.length != 0) {
      _.each(res, item => {
        if (item.volunteers && item.volunteers.length != 0) {
          _.each(item.volunteers, vol => {
            UserDAO.getUserById(vol).then(response => {
              if (response.length == 0) {
                GuestDAO.getGuestById(vol).then(gusetRes => {
                  if (gusetRes.length != 0) {
                    EventItemDAO.sendOneDayReminder(gusetRes[0], item).then(result => {})
                  }
                })
              } else {
                EventItemDAO.sendOneDayReminder(response[0], item).then(result => {})
              }
            })

          })
        }
      })
    }

  }).catch(err => {
    console.log(err)
  })
});

RoutesConfig.init(app);
DBConfig.init();
Routes.init(app, express.Router());

http.createServer(app)
  .listen(PORT, () => {
    console.log(`up and running @: ${os.hostname()} on port: ${PORT}`);
    console.log(`enviroment: ${process.env.NODE_ENV}`);
  });

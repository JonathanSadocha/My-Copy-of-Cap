import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef, ViewChild, TemplateRef, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
import {NgbModal,NgbModalConfig} from '@ng-bootstrap/ng-bootstrap';
import { detectChanges } from '@angular/core/src/render3';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AccountComponent implements OnInit {
  account: Object;
  role: string;

  constructor( private userService: UserService, private modal: NgbModal, config: NgbModalConfig, private router: Router, private ref: ChangeDetectorRef) {
  
  }

  ngOnInit(): void {
     this.userService.getSessionUser(localStorage.getItem('usrInfo')).subscribe(res=>{
       this.role = res[0].role;
      this.account=res[0]
      this.ref.markForCheck()
      
    })

  }


}

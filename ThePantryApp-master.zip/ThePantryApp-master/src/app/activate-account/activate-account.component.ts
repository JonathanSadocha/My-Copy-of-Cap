import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef, ViewChild, TemplateRef, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../user.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MustMatch } from './must-match.validator';
import { NgxSpinnerService } from 'ngx-spinner';
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-activate-account',
  templateUrl: './activate-account.component.html',
  styleUrls: ['./activate-account.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ActivateAccountComponent implements OnInit {
  @ViewChild('successModal') successModal: TemplateRef < any > ;
  @ViewChild('invalidToken') invalidToken: TemplateRef < any > ;
  @ViewChild('confirmPassword') confirmPasswordField: ElementRef;
  submitted: Boolean = false;
  validToken: boolean = false;
  param1: String;
  param2: String;
  activateForm: FormGroup;
  user: Object;
  constructor(private route: ActivatedRoute, private userService: UserService, private router: Router, private ref: ChangeDetectorRef,private modal: NgbModal, config: NgbModalConfig, private formBuilder: FormBuilder, private spinner: NgxSpinnerService) { 
    config.backdrop = "static";
    config.keyboard = false;
  }

  ngOnInit() {
    this.spinner.show()
    this.activateForm = this.formBuilder.group({
      password:['', [Validators.required, Validators.minLength(6)]],
      confirmPassword:['', [Validators.required]],

    }, {
      validator: MustMatch('password', 'confirmPassword')
    });
    this.param1 = this.route.snapshot.paramMap.get('token')
    if(this.param1){
      this.userService.getUserByToken(this.param1).subscribe(res=>{
        if(res[0].password == this.param1){
          //allows the user to activate their password
          this.user = res[0]
          this.validToken = true;
          this.ref.markForCheck()
          setTimeout(() => {
            /** spinner ends after 5 seconds */
            this.spinner.hide();
        }, 5000);
        }
        else{
          setTimeout(() => {
            /** spinner ends after 5 seconds */
            this.spinner.hide();
        }, 5000);
          this.validToken = false;
        }
      })
    }
    else{
      this.validToken = false;
      setTimeout(() => {
        /** spinner ends after 5 seconds */
        this.spinner.hide();
    }, 5000);
      // handle the incorrect password token with a ng template
    }

  }


  get f(){
    return this.activateForm.controls
  }

  onSubmit(){
    this.submitted = true;
    // stop here if form is invalid
    if (this.activateForm.invalid) {
      if(!this.activateForm.controls.confirmPassword.valid){
        this.confirmPasswordField.nativeElement.focus();
      }
      console.log('invalid')
      return;
    }else{
      this.activatePassword()
    }
  }

  activatePassword(){
    this.user['password'] = this.activateForm.controls['password'].value
    this.userService.updateAccountPassword(this.user).subscribe(res=>{
      delete res.password
      this.userService.user = res
      this.userService.loggedIn = true;
      localStorage.setItem('usrInfo', res._id)
      this.modal.open(this.successModal, {size: 'lg'})
    })
  }


  goTo(_location){
    this.router.navigate([_location]);
    this.modal.dismissAll();
  }

}

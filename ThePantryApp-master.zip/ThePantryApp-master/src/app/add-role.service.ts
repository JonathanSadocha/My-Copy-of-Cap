import {Injectable, LOCALE_ID, Inject} from '@angular/core';
import {DatePipe} from '@angular/common';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'node_modules/rxjs';
import {Location} from '@angular/common'
import { NavigationEnd, Router } from 'node_modules/@angular/router';
import * as moment from 'moment';

@Injectable({
  providedIn: 'root'
})
export class AddRoleService {

  // apiUrl = 'http://localhost:3333/api/'
  apiUrl = 'http://volunteer.thepantry.gr:3333/api/'

  constructor(private http: HttpClient, private location: Location, router: Router, @Inject(LOCALE_ID) private locale: string) {
    // this.apiUrl = 'http://localhost:3333/api/';
    this.apiUrl = 'http://volunteer.thepantry.gr:3333/api/'

   }

  createRole(role): Observable<any>{
    return this.http.post(this.apiUrl + 'roles/create', role)
  }


}

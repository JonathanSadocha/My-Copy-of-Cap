import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef, TemplateRef, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ChangeRolesComponent } from '../change-roles/change-roles.component';
import { AddRoleService } from '../add-role.service';
import { HttpClient } from '@angular/common/http';
import { Location } from '@angular/common';
import { NgModule }      from '@angular/core';
import {NgbModal,NgbModalConfig} from '@ng-bootstrap/ng-bootstrap';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-add-role',
  templateUrl: './add-role.component.html',
  styleUrls: ['./add-role.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AddRoleComponent implements OnInit {
  @ViewChild('successModal') successModal: TemplateRef<any>;
  submitted;
  // apiUrl = 'http://localhost:3333/api/'
  apiUrl = 'http://volunteer.thepantry.gr:3333/api/'


  roleForm: FormGroup;
  constructor(private addService: AddRoleService, private http: HttpClient, private ref: ChangeDetectorRef, private formBuilder: FormBuilder, private location : Location, private modal: NgbModal, private router: Router) {
    // this.apiUrl = 'http://localhost:3333/api/'
    this.apiUrl = 'http://volunteer.thepantry.gr:3333/api/'


   }

  ngOnInit() {
    this.roleForm = this.formBuilder.group({
      role: ['', [Validators.required]],
      time: ['', [Validators.required]],
      qty: [, [Validators.required]],
      description: ['', [Validators.required]],
      startDate: [new Date(), [Validators.required]],
      endDate: [new Date(), [Validators.required]]

    });
      this.ref.markForCheck()

  }

  get f(){
    return this.roleForm.controls
  }



  onSubmit() {
    this.submitted = true;
    if (this.roleForm.invalid) {
      return;
    }else{
      var ctrl = this.f;
      var objOut = {
        role: ctrl['role'].value,
        time: ctrl['time'].value,
        qty: ctrl['qty'].value,
        description: ctrl['description'].value,
        startDate: ctrl['startDate'].value,
        endDate: ctrl['endDate'].value,
        days:{monday:false, tuesday: false, wednesday: false, thursday: false, friday: false, saturday: false}
      }
      
      this.createRole(objOut);
    }
  }

  createRole(obj){
    this.addService.createRole(obj).subscribe(res=>{
      //do something here, display a succuess notification (check nicks modal stuff for edit-account)
      //reroute them to the roles page when they "close" the modal
      this.modal.open(this.successModal, {size: 'lg'})
      this.ref.markForCheck();
    })
  }

  goBack(){
    this.location.back();
  }

  goToRoles(){
    this.modal.dismissAll();
    this.router.navigate(['roles']);
  }

}

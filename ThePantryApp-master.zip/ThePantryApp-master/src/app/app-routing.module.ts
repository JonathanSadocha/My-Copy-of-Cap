import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { CalendarComponent } from './calendar/calendar.component';
import { ChangeRolesComponent } from './change-roles/change-roles.component';
import { SpecialEventsComponent } from './special-events/special-events.component';
import { AddRoleComponent } from './add-role/add-role.component';
import { EditRoleComponent } from './edit-role/edit-role.component';
import { CreateAccountComponent } from './create-account/create-account.component';
import { LoginComponent } from './login/login.component';
import { AccountComponent } from './account/account.component';
import { EditAccountComponent } from './edit-account/edit-account.component';
import { DownloadGuestsComponent } from './download-guests/download-guests.component';
import { DownloadUsersComponent } from './download-users/download-users.component';
import { ManualUserComponent } from './manual-user/manual-user.component';
import { AuthGuard } from './auth/auth.guard';
import { ActivateAccountComponent } from './activate-account/activate-account.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { UserSearchComponent } from './user-search/user-search.component';
import { UserEditComponent } from './user-edit/user-edit.component';
import { SpecialEventEditComponent } from './special-event-edit/special-event-edit.component';
import { SpecialEventNewComponent } from './special-event-new/special-event-new.component';

const routes: Routes = [
  {path: 'calendar', component: CalendarComponent},
  {path: 'roles', component: ChangeRolesComponent, canActivate: [AuthGuard]},
  {path: 'add-role', component: AddRoleComponent, canActivate: [AuthGuard]},
  {path: 'edit-role/:id', component: EditRoleComponent, canActivate: [AuthGuard]},
  {path: 'special-events', component: SpecialEventsComponent, canActivate: [AuthGuard]},
  {path: 'special-events/new', component: SpecialEventNewComponent, canActivate: [AuthGuard]},
  {path: 'special-events/edit/:id', component: SpecialEventEditComponent, canActivate: [AuthGuard]},
  {path: 'login', component: LoginComponent},
  {path: 'login/newUser', component: CreateAccountComponent},
  {path: 'account', component: AccountComponent},
  {path: 'account/update', component: EditAccountComponent},
  {path:'account/download/users', component: DownloadUsersComponent, canActivate: [AuthGuard]},
  {path:'account/download/guests', component: DownloadGuestsComponent, canActivate: [AuthGuard]},
  {path:'users/manuallly-add', component: ManualUserComponent, canActivate: [AuthGuard]},
  {path:'users/search', component: UserSearchComponent, canActivate: [AuthGuard]},
  {path:'users/edit/:id', component: UserEditComponent, canActivate: [AuthGuard]},
  {path:'user/reset/password/:token', component: ActivateAccountComponent},
  {path:'reset-password', component: ResetPasswordComponent},
  {path: '', redirectTo: 'calendar', pathMatch: 'prefix'},
  {path: '**', redirectTo: 'calendar', pathMatch: 'prefix'}
]

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(routes, {useHash: false}),
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule],
})
export class AppRoutingModule { }

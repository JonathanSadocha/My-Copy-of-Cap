import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef, ViewChild, TemplateRef, ElementRef } from '@angular/core';
import {FormBuilder,FormGroup,Validators} from '@angular/forms';
import { NgbModal,NgbModalConfig} from '@ng-bootstrap/ng-bootstrap';
import { UserService } from './user.service';
import * as moment from 'moment';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AppComponent implements OnInit {
  @ViewChild('loginModal') loginModal: TemplateRef < any > ;
  @ViewChild('invalidCred') invalidCred: ElementRef;
  invalidLogin: Boolean = false;
  loginUserForm: FormGroup;
  submitted: Boolean = false;
  cookieValue= 'UNKNOWN';
  title = 'ThePantryApp';
  loginInfo = {
    email: '',
    password: ''
  }

  userData = {};

  modalReference;
  constructor(private modal: NgbModal, config: NgbModalConfig, public userService: UserService, private formBuilder: FormBuilder, private ref: ChangeDetectorRef, private router: Router){

  }

  get f() {
    return this.loginUserForm.controls;
  }

  ngOnInit(): void {
    var regexpEmail = new RegExp(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
    this.loginUserForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.pattern(regexpEmail)]],
      password:['', [Validators.required]]

    });
    if(localStorage.getItem('usrInfo')!=null){
      //run a query to get the userback without the pwrd
      this.userService.getSessionUser(localStorage.getItem('usrInfo')).subscribe(res=>{
        this.userService.user = res[0];
        this.userService.loggedIn = true;
        this.ref.markForCheck();
      })
    }
    else{
      this.userService.user = {};
      this.userService.loggedIn = false;
    }
  }

  //logout the user
  logout(){
    this.userService.user = {};
    this.userService.loggedIn = false;
    localStorage.removeItem('usrInfo');
  }

  //login form submitted
  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.loginUserForm.invalid) {
      return;
    }else{
      this.loginUser()
    }
  }


  goTo(_location){
    this.router.navigate([_location]);
    this.modal.dismissAll();
  }


//opens the login modal
  openLoginModal() {
    this.modalReference = this.modal.open(this.loginModal, {
      size: 'lg'
    })
  }

  //checks if the users login input is valid
  loginUser() {
    var userCtrl = this.loginUserForm.controls
    this.loginInfo.email = userCtrl.email.value.toLowerCase();
    this.loginInfo.password = userCtrl.password.value;

    this.userService.loginUser(this.loginInfo).toPromise().then(res =>{
      if(res == null || res == {}){
        //login is invalid
        this.invalidLogin = true;
      }else{
        //login is valid
        this.userService.user = res
        this.userService.loggedIn = true;
        localStorage.setItem('usrInfo', res._id)
        this.invalidLogin = false;
        this.modalReference.close();
        this.ref.markForCheck();
      }
    }).catch(err =>{
      this.invalidLogin = true;
    });
  }



}

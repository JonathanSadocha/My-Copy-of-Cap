import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { UiSwitchModule } from 'ngx-ui-switch';

import {NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxSpinnerModule } from 'ngx-spinner';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { OwlFormFieldModule, OwlInputMaskModule, OwlInputModule } from 'owl-ng';

import { MDBBootstrapModule } from 'angular-bootstrap-md';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';


import { CalendarComponent } from './calendar/calendar.component';
import { ChangeRolesComponent } from './change-roles/change-roles.component';
import { SpecialEventsComponent } from './special-events/special-events.component';

import { DataTableModule } from 'angular-6-datatable';

import 'flatpickr/dist/flatpickr.css';
import { AddRoleComponent } from './add-role/add-role.component';
import { EditRoleComponent } from './edit-role/edit-role.component';

//use the meta field for custom data
import { CreateAccountComponent } from './create-account/create-account.component';
import { LoginComponent } from './login/login.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { ModalModule } from 'ngx-bootstrap/modal';
import { TimepickerModule } from 'ngx-bootstrap/timepicker';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { AccountComponent } from './account/account.component';
import { EditAccountComponent } from './edit-account/edit-account.component';
import { DownloadUsersComponent } from './download-users/download-users.component';
import { DownloadGuestsComponent } from './download-guests/download-guests.component';
import { UserService } from './user.service';
import { SpecialEventEditComponent } from './special-event-edit/special-event-edit.component';
import { SpecialEventNewComponent } from './special-event-new/special-event-new.component';
import { ManualUserComponent } from './manual-user/manual-user.component';
import { ActivateAccountComponent } from './activate-account/activate-account.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { UserSearchComponent } from './user-search/user-search.component';
import { UserEditComponent } from './user-edit/user-edit.component';

//use the meta field for custom data
@NgModule({
  declarations: [
    AppComponent,
    CalendarComponent,
    ChangeRolesComponent,
    SpecialEventsComponent,
    CreateAccountComponent,
    LoginComponent,
    ChangeRolesComponent,
    AddRoleComponent,
    EditRoleComponent,
    AccountComponent,
    EditAccountComponent,
    DownloadUsersComponent,
    DownloadGuestsComponent,
    SpecialEventEditComponent,
    SpecialEventNewComponent,
    ManualUserComponent,
    ActivateAccountComponent,
    ResetPasswordComponent,
    UserSearchComponent,
    UserEditComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    OwlDateTimeModule,
    OwlNativeDateTimeModule,
    OwlFormFieldModule,
    OwlInputMaskModule,
    OwlInputModule,
    CommonModule,
    UiSwitchModule,
    NgbModule,
    NgxSpinnerModule,
    MDBBootstrapModule.forRoot(),
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    BrowserModule,
    ReactiveFormsModule,
    BsDatepickerModule.forRoot(),
    ModalModule.forRoot(),
    TimepickerModule.forRoot(),
    TooltipModule.forRoot(),
    DataTableModule
  ],
  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Component,ChangeDetectorRef,OnInit,ViewChild,TemplateRef,ChangeDetectionStrategy,Inject,LOCALE_ID, ElementRef} from '@angular/core';
import { Router } from '@angular/router';
import {HttpClient} from '@angular/common/http';
import {FormBuilder,FormGroup,Validators} from '@angular/forms';
import {Observable} from 'rxjs';
import {CalendarService} from './calendar.service';
import { UserService } from '../user.service';

import {NgbModal,NgbModalConfig} from '@ng-bootstrap/ng-bootstrap';
import {DatePipe} from '@angular/common';
import {NgxSpinnerService} from 'ngx-spinner';

//do not remove '* as' it will result in errors if removed.
import * as moment from 'moment';
import * as _ from 'underscore';
import { toDate } from '@angular/common/src/i18n/format_date';




@Component({
  selector: 'app-calendar',
  templateUrl: './calendar.component.html',
  styleUrls: ['./calendar.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CalendarComponent implements OnInit {
  @ViewChild('infoModal') infoModal: TemplateRef < any > ;
  @ViewChild('specialEventInfoModal') specialEventInfoModal: TemplateRef < any > ;
  @ViewChild('confirmModal') confirmModal: TemplateRef < any > ;
  @ViewChild('guestModal') guestModalTemplate: TemplateRef < any > ;
  @ViewChild('guestModalSE') guestModalSETemplate: TemplateRef < any > ;
  @ViewChild('loginModal') loginModal: TemplateRef < any > ;
  @ViewChild('listTab') listTab: TemplateRef < any > ;
  @ViewChild('fullEventModal') fullEventModal: TemplateRef < any > ;
  @ViewChild('registerModal') registerModal: TemplateRef < any > ;
  @ViewChild('registerModalSE') registerModalSE: TemplateRef < any > ;
  @ViewChild('invalidCred') invalidCred: ElementRef;

  // apiUrl: 'http://localhost:3333/api/';
  apiUrl = 'http://volunteer.thepantry.gr:3333/api/'



  public hoursFilter = (d: Date): boolean => {
    const day = d.getDay();
    return day !== 0 && day !== 6 && day !== 2
  }

  userDateRange: Date[] = [];

  modalReference;

  userInput: {
    email: '',
    password: ''
  }


  loginError: Boolean = false;
  loginStatus: Boolean = false;
  guest: {
    firstName: '',
    lastName: '',
    email: '',
    address: '',
    address2: '',
    city: '',
    state: 'MI',
    zip: '',
    phone: '',
    race: '',
    gender: '',
    employer: '',
    affiliation: '',
    accommodations: '',
    allergy: '',
    emgContactFName: '',
    emgContactLName: '',
    emgContactPhone: ''

  };
  registerForm: FormGroup;
  loginUserForm: FormGroup;
  submitted: Boolean = false;
  currentDate: Date = new Date();
  userData = {
    loggedIn: false,
    email: '',
    password: '',
  }

  modalData = {
    event: {
      _id: null,
      startDate: null,
      endDate: null,
      time: null,
      qty: null,
      role: null
    },
    day: ''
  }
  specialEventData:{
    _id:null,
    title:null,
    description: null,
    volunteersNeeded:null,
    volunteers: String[],
    startTime:null,
    endTime:null,
    startDate: null,
    endDate: null,
  }
  guestRegistration: Boolean = false;
  eventItemData: Object;
  view: string = 'month';
  viewDate: Date = new Date();
  viewDateSE: Date = new Date();

  maxDate: Date = new Date();
  eventItems$: Observable < Object[] > ;
  specialEvents$: Observable < Object[] > ;
  roles$;
  rangeDates: Array < any > = [];
  activeDayIsOpen: boolean = false;
  firstRange = true;
  guestData: Object;
  invalidLogin: Boolean = false;
  specialEventRange=[];
  emptySpecial: Boolean = false;
  roleHolder: String = '';

  constructor(private calendarService: CalendarService, private router: Router, private ref: ChangeDetectorRef, private userService: UserService, private cdr: ChangeDetectorRef, private http: HttpClient, private modal: NgbModal, config: NgbModalConfig, private formBuilder: FormBuilder, private spinner: NgxSpinnerService, @Inject(LOCALE_ID) private locale: string) {
    config.backdrop = "static";
    config.keyboard = false;

  }




  ngOnInit(): void {
    // this.apiUrl = 'http://localhost:3333/api/'
    this.apiUrl = 'http://volunteer.thepantry.gr:3333/api/'

    this.viewDate = moment(this.viewDate).add(1, 'days').toDate();
    this.userDateRange.push(this.viewDate);
    this.userDateRange.push(moment(this.viewDate).add(4, 'days').toDate())
    this.maxDate = moment(this.maxDate).add(1, 'months').toDate();
    this.viewDateSE = moment(this.viewDateSE).add(1, 'days').toDate();
    this.specialEventRange.push(this.viewDateSE);
    this.specialEventRange.push(moment(this.viewDateSE).add(30, 'days').toDate());
    this.roles$ = [];
    this.getSpecialEvents();
    this.getEventItems();
    this.fetchEvents();
    var regexpEmail = new RegExp(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);

    this.registerForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email: ['', [Validators.required, Validators.pattern(regexpEmail)]],
      address: ['', [Validators.required]],
      address2: [''],
      city: ['', [Validators.required]],
      state: ['MI', [Validators.required]],
      zip: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(5)]],
      phone: ['', [Validators.required]],
      race: ['', [Validators.required]],
      gender: ['', [Validators.required]],
      employer: ['', [Validators.required]],
      affiliation: [''],
      accommodations: [''],
      allergy: [''],
      emgContactFName: ['', [Validators.required]],
      emgContactLName: ['', [Validators.required]],
      emgContactPhone: ['', [Validators.required]]

    });
    this.guest =  {
      firstName: '',
      lastName: '',
      email: '',
      address: '',
      address2: '',
      city: '',
      state: 'MI',
      zip: '',
      phone: '',
      race: '',
      gender: '',
      employer: '',
      affiliation: '',
      accommodations: '',
      allergy: '',
      emgContactFName: '',
      emgContactLName: '',
      emgContactPhone: ''

    };

    this.loginUserForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.pattern(regexpEmail)]],
      password:['', [Validators.required]]

    });
    this.ref.markForCheck()

  }





  itemCheck(item, day) {
    this.spinner.show()
    var timeComp = new DatePipe(this.locale).transform(new Date(item.startDate), 'HH', this.locale)
    var newTime = moment(day).hour(parseInt(timeComp))
    var eventComp = new DatePipe(this.locale).transform(new Date(item.startDate), '-HH:mm', this.locale)
    eventComp = day + eventComp + '-' + item.role
    //possibly filter out the start of the day on thursdays here
    var arrFilter = []
    _.each(this.eventItems$, function (evt) {
      if (evt.eventId == eventComp && evt.volunteers.length >= evt.qty) {
        arrFilter.push(evt)
      }
    })

    this.spinner.hide()
    if (arrFilter.length == 0) {
      if(moment(day).day() == 4 && this.roleHolder != item.role ){
        this.roleHolder = item.role
        return true
      }
      else if(moment(day).day() == 4){
        return false;
      }
      else{
        this.roleHolder = item.role

        return true
      }
    } else {
      return false
    }
  }


  enumerateDaysBetweenDates(startDate, endDate) {
    var currDate = moment(startDate).startOf('day');
    var lastDate = moment(endDate).endOf('day');
    this.rangeDates = [];
    while (currDate.diff(lastDate) < 0) {
      var day = moment(currDate).day()
      if (day !== 0 && day !== 6 && day !== 2) {
        this.rangeDates.push(new DatePipe(this.locale).transform(currDate.toISOString(), 'yyyy-MM-dd', this.locale));
        currDate.add(1, 'days')
      } else {
        currDate.add(1, 'days')

      }
    }
    return this.rangeDates;
  };

  modifyButtonTime(role,startTime,day){
    var roleOut = role.charAt(0).toUpperCase()+ role.slice(1);
    if(moment(day).day() == 4 ){
      return roleOut + ' - 5:30 PM'
    }else{
      return roleOut + ' - ' + moment(startTime).format("h:mm A")
    }
  }




  getEventItems() {
    this.enumerateDaysBetweenDates(this.userDateRange[0], this.userDateRange[1])
    this.calendarService.getEventItemOpen(this.userDateRange).subscribe(output => {
      this.eventItems$ = output
      this.cdr.markForCheck()

      return this.eventItems$
    })
  }

  findOpenings() {

    if (this.userDateRange.length == 2) {
      this.firstRange = false;

      this.getEventItems()

    } else {
      console.log('range not selected')
    }


  }


  get f() {
    return this.registerForm.controls;
  }

  get u() {
    return this.loginUserForm.controls;
  }

  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.registerForm.invalid) {
      return;
    }else{
      this.registerGuestEvent()
    }


  }

  onSubmitSE() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.registerForm.invalid) {
      return;
    }else{
      this.registerGuestEventSE()
    }


  }


  //gets the roles and popultates them into the calendar
  fetchEvents(): void {
    this.calendarService.getAll().subscribe(output => {
      this.roles$ = output
    })

  }

  //gets all the special events for the next 30 days
  getSpecialEvents(){
    this.calendarService.getSpecialEvents(this.specialEventRange).subscribe(output => {
      if(output.length == 0){
        this.emptySpecial = true;
      }else{
        this.emptySpecial = false;
      }
      this.specialEvents$ = output
      this.cdr.markForCheck()
    })
  }


  //checks if the eventItem exists in the database and if it does not it creates a new item in the database
  registerEventItem(itemId) {
    let promise = new Promise((resolve, reject) => {
      this.http.get(this.apiUrl + 'eventItems/' + itemId).toPromise()
        .then(res => {
          var response = res
          if (response == null) {
            this.eventItemData = res;
            var roleHour = moment(this.modalData.event.startDate).hours()
            var roleEndHour = moment(this.modalData.event.endDate).hours()
            var startOut = moment(this.modalData.day).hour(roleHour)
            var endOut = moment(this.modalData.day).hour(roleEndHour)
            let eventPost = {
              eventId: itemId,
              role: this.modalData.event._id,
              time: this.modalData.event.time,
              qty: this.modalData.event.qty,
              startDate: moment(startOut).toDate(),
              endDate: moment(endOut).toDate(),
              volunteers: [this.userService.user['_id']]
            }
            //post that creates the new event
            this.http.post(this.apiUrl + 'eventItems/new', eventPost)
              .toPromise()
              .then(res => {
                this.modal.open(this.confirmModal, {
                  size: 'lg'
                })
                this.getEventItems()
                resolve();
              }, err => {
                console.log(err)
              })
          } else {
            var item = JSON.parse(JSON.stringify(res));
            if (item.volunteers.length >= this.modalData.event.qty) {
              //event is full, this is for if there is some error and the event is not displayed properly
              this.modal.open(this.fullEventModal, {
                size: 'lg'
              })

            } else {
              //updates the current eventItem to add a new user to it
              item.volunteers.push(this.userService.user['_id'])
              this.http.post(this.apiUrl + 'eventItems/' + item._id, item).toPromise()
                .then(res => {
                  this.getEventItems();
                  this.modal.open(this.confirmModal, {
                    size: 'lg'
                  })
                })
            }
          }
          resolve(res)
        }, err => {
          console.log(err)
        })

    })
    return promise;
  }



  guestRegisterEventItem(itemId) {
    let promise = new Promise((resolve, reject) => {
      this.http.get(this.apiUrl + 'eventItems/' + itemId).toPromise()
        .then(res => {
          var response = res
          if (response == null) {
            this.eventItemData = res;
            var roleHour = moment(this.modalData.event.startDate).hours()
            var roleEndHour = moment(this.modalData.event.endDate).hours()
            var startOut = moment(this.modalData.day).hour(roleHour)
            var endOut = moment(this.modalData.day).hour(roleEndHour)
            let eventPost = {
              eventId: itemId,
              role: this.modalData.event._id,
              time: this.modalData.event.time,
              qty: this.modalData.event.qty,
              startDate: moment(startOut).toDate(),
              endDate: moment(endOut).toDate(),
              volunteers: [this.guestData['_id']]
            }
            //post that creates the new event
            this.http.post(this.apiUrl + 'eventItems/new', eventPost)
              .toPromise()
              .then(res => {
                this.modal.open(this.confirmModal, {
                  size: 'lg'
                })
                this.getEventItems()
                resolve();
              }, err => {
                console.log(err)
              })
          } else {
            var item = JSON.parse(JSON.stringify(res));
            if (item.volunteers.length >= this.modalData.event.qty) {
              //event is full, this is for if there is some error and the event is not displayed properly
              this.modal.open(this.fullEventModal, {
                size: 'lg'
              })

            } else {
              //updates the current eventItem to add a new user to it
              item.volunteers.push(this.guestData['_id'])
              this.http.post(this.apiUrl + 'eventItems/' + item._id, item).toPromise()
                .then(res => {
                  this.getEventItems();
                  this.guestRegistration = false;
                  this.modal.open(this.confirmModal, {
                    size: 'lg'
                  })
                })
            }
          }
          resolve(res)
        }, err => {
          console.log(err)
        })

    })
    return promise;
  }

 loginSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.loginUserForm.invalid) {
      return;
    }else{
      this.loginUser()
    }
  }
//logins the user
loginUser() {
  var userCtrl = this.loginUserForm.controls
  this.userService.loginUser({email: userCtrl.email.value.toLowerCase(), password: userCtrl.password.value}).toPromise().then(res =>{
    if(res == null || res == {}){
      //login is invalid
      this.invalidLogin = true;
    }else{
      //login is valid
      this.userService.user = res
      this.userService.loggedIn = true;
      localStorage.setItem('usrInfo', res._id)
      this.invalidLogin = false;
      this.modalReference.close();
    }
  }).catch(err =>{
    this.invalidLogin = true;
  });
}

  //handels eventitem click on calendar
  eventClicked(modal, event, day): void {
    if(moment(day).day() == 4 ){
      event.startDate= moment(event.startDate).hour(17).minute(30).toDate()
      event.endDate = moment(event.endDate).hour(20).minute(15).toDate()
      this.modalData.event = event
      this.modalData.day = day
    }
    else{
      this.modalData.event = event
      this.modalData.day = day
    }

    var eventComp = new DatePipe(this.locale).transform(new Date(event.startDate).toISOString(), '-HH:mm', this.locale)
    eventComp = day + eventComp + '-' + event.role
    this.http.get(this.apiUrl + 'eventItems/' + eventComp).toPromise()
      .then((res: []) => {
        this.eventItemData = res;
      })
    this.modal.open(this.infoModal, {
      size: 'lg'
    });
  }

  //handles special event information button press
  specialEventInfo(event): void{
    this.specialEventData = event
    this.modal.open(this.specialEventInfoModal, {
      size: 'lg'
    });
  }

  //opens the register modal
  showRegisterModal(modal) {
    this.modal.open(modal, {
      size: 'lg'
    });
  }

  //opens the guest modal
  openGuestModal() {
    this.modal.open(this.guestModalTemplate, {
      size: 'lg'
    })
  }

  openGuestModalSE() {
    this.modal.open(this.guestModalSETemplate, {
      size: 'lg'
    })
  }

  //registers the user for the event
  registerUserEvent() {
    var eventComp = new DatePipe(this.locale).transform(new Date(this.modalData.event.startDate).toISOString(), '-HH:mm', this.locale)
    eventComp = this.modalData.day + eventComp + '-' + this.modalData.event.role
    if(this.guestRegistration){
      this.guestRegisterEventItem(eventComp);
    }else{
      this.registerEventItem(eventComp);
    }
  }

    //registers the user for the Specialevent
    registerUserEventSE() {
      if(this.guestRegistration){
        // this.guestData['_id']
        if(this.submitted==true){
          this.specialEventData.volunteers.push(this.guestData['_id'])
          this.calendarService.updateSpecialEvent(this.specialEventData).subscribe(res=>{
            if(res){
              this.modal.open(this.confirmModal, {size:'lg'})
            }
          })
        }


      }else{
        this.specialEventData.volunteers.push(this.userService.user['_id'])
        this.calendarService.updateSpecialEvent(this.specialEventData).subscribe(res=>{
          if(res){
            this.modal.open(this.confirmModal, {size:'lg'})
          }
        })
      }
    }

    registerGuestEventSE() {
      this.submitted = true;
      // stop here if form is invalid
      if (!this.registerFormCheck()) {

        return;
      } else {
        //create the guest in the guest database and then use that to add user to the guest to the event
        var formHold = this.registerForm.controls;
        this.guest.accommodations = formHold.accommodations.value
        this.guest.address = formHold.address.value
        this.guest.address2 = formHold.address2.value
        this.guest.affiliation = formHold.affiliation.value
        this.guest.allergy = formHold.allergy.value
        this.guest.city = formHold.city.value
        this.guest.email = formHold.email.value
        this.guest.emgContactFName = formHold.emgContactFName.value
        this.guest.emgContactLName = formHold.emgContactLName.value
        this.guest.emgContactPhone = formHold.emgContactPhone.value
        this.guest.employer = formHold.employer.value
        this.guest.firstName = formHold.firstName.value
        this.guest.gender = formHold.gender.value
        this.guest.lastName = formHold.lastName.value
        this.guest.phone = formHold.phone.value
        this.guest.race = formHold.race.value
        this.guest.state = formHold.state.value
        this.guest.zip = formHold.zip.value
        this.calendarService.registerGuest(this.guest).toPromise().then(res =>{
          if(res !=null){
            this.guestData = res;
            this.guestRegistration = true;
            this.showRegisterModal(this.registerModalSE)
          }
        }).catch(err=>{
          console.log(err)
        })
      }

    }

  registerGuestEvent() {
    this.submitted = true;
    // stop here if form is invalid
    if (!this.registerFormCheck()) {

      return;
    } else {
      //create the guest in the guest database and then use that to add user to the guest to the event
      var formHold = this.registerForm.controls;
      this.guest.accommodations = formHold.accommodations.value
      this.guest.address = formHold.address.value
      this.guest.address2 = formHold.address2.value
      this.guest.affiliation = formHold.affiliation.value
      this.guest.allergy = formHold.allergy.value
      this.guest.city = formHold.city.value
      this.guest.email = formHold.email.value
      this.guest.emgContactFName = formHold.emgContactFName.value
      this.guest.emgContactLName = formHold.emgContactLName.value
      this.guest.emgContactPhone = formHold.emgContactPhone.value
      this.guest.employer = formHold.employer.value
      this.guest.firstName = formHold.firstName.value
      this.guest.gender = formHold.gender.value
      this.guest.lastName = formHold.lastName.value
      this.guest.phone = formHold.phone.value
      this.guest.race = formHold.race.value
      this.guest.state = formHold.state.value
      this.guest.zip = formHold.zip.value
      this.calendarService.registerGuest(this.guest).toPromise().then(res =>{
        if(res !=null){
          this.guestData = res;
          this.guestRegistration = true;
          this.showRegisterModal(this.registerModal)
        }
      }).catch(err=>{
        console.log(err)
      })
    }

  }

  registerFormCheck() {
    var formHold = this.registerForm.controls;
    if (formHold.firstName.valid && formHold.lastName.valid && formHold.email.valid && formHold.phone.valid && formHold.address.valid && formHold.city.valid && formHold.zip.valid && formHold.race.valid && formHold.gender.valid && formHold.employer.valid && formHold.emgContactFName.valid && formHold.emgContactLName.valid && formHold.emgContactPhone.valid){
      return true;
    }
    else{
      return false;
    }
  }

  //goes to create account
  goToCreateAccount(){
    this.router.navigate(['login/newUser']);
    this.modal.dismissAll();
  }

  //opens the login modal
  openLoginModal() {
    this.modalReference = this.modal.open(this.loginModal, {
      size: 'lg'
    })
  }


  //closes all modals
  closeAll() {
    this.modal.dismissAll();
  }


  setRole(value) {}


}

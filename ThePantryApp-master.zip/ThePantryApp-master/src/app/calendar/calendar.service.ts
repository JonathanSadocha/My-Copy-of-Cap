import {Injectable, LOCALE_ID, Inject} from '@angular/core';
import {DatePipe} from '@angular/common';
import {HttpClient} from '@angular/common/http';
import {Observable, range} from '../../../node_modules/rxjs';
import {Location} from '@angular/common'
import { AppComponent } from '../app.component';
import { NavigationEnd, Router } from '../../../node_modules/@angular/router';
import * as moment from 'moment';

@Injectable({
  providedIn: 'root'
})
export class CalendarService {

  rangeDates: Array<any> = [];
  eventItems = Array();
  eventTest: Observable<any>;
  // apiUrl = 'http://localhost:3333/api/';
  apiUrl = 'http://volunteer.thepantry.gr:3333/api/'

  constructor(private http: HttpClient, private location: Location, router: Router, @Inject(LOCALE_ID) private locale: string) {
    // this.apiUrl = 'http://localhost:3333/api/'
    this.apiUrl = 'http://volunteer.thepantry.gr:3333/api/'

  }

  enumerateDaysBetweenDates(startDate, endDate) {


    var currDate = moment(startDate).startOf('day');
    var lastDate = moment(endDate).endOf('day');
    this.rangeDates=[];
    while(currDate.diff(lastDate) < 0) {

        this.rangeDates.push(new DatePipe(this.locale).transform(currDate.toISOString(), 'yyyy-MM-dd', this.locale));
        currDate.add(1, 'days')
    }
    return this.rangeDates;
};
  getEventItemOpen(userDateRange): Observable < any> {
        var rangeStart = moment(userDateRange[0]).hour(0).minute(0).second(0).millisecond(0)
        var rangeEnd = moment(userDateRange[1]).hour(0).minute(0).second(0).millisecond(0)
        this.enumerateDaysBetweenDates(rangeStart.toISOString(), rangeEnd.toISOString())

        return this.http.get(this.apiUrl +'eventItems/range/'+rangeStart.toISOString() + '/' + rangeEnd.toISOString())


  }

  getAll():Observable<any>{
    return this.http.get(this.apiUrl + 'roles/getAll')
  }


  getSpecialEvents(dateRange):Observable<any>{
    var rangeStart = moment(dateRange[0]).hour(0).minute(0).second(0).millisecond(0)
    var rangeEnd = moment(dateRange[1]).hour(0).minute(0).second(0).millisecond(0)
    return this.http.get(this.apiUrl + 'specialEvent/range/get/'+rangeStart.toISOString()+'/'+rangeEnd.toISOString())
  }

  registerGuest(guest): Observable<any>{
    return this.http.post(this.apiUrl + 'guest/new', guest)
  }


  updateSpecialEvent(event): Observable<any>{
    return this.http.post(this.apiUrl+'specialEvent/update', event)
  }

}

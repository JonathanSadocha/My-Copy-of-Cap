import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { RouterLink, Router } from '@angular/router';
import {HttpClient} from '@angular/common/http';
import { UserService } from '../user.service';

@Component({
  selector: 'app-change-roles',
  templateUrl: './change-roles.component.html',
  styleUrls: ['./change-roles.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChangeRolesComponent implements OnInit {

  roles;
  selectedRole;
  // apiUrl = 'http://localhost:3333/api/';
  apiUrl = 'http://volunteer.thepantry.gr:3333/api/'


  constructor(private http: HttpClient, private uService: UserService, private ref: ChangeDetectorRef, private router: Router) {
    // this.apiUrl = 'http://localhost:3333/api/'
    this.apiUrl = 'http://volunteer.thepantry.gr:3333/api/'

  }

  ngOnInit() {
    this.roles = [];
    this.getRoles();
  }

  getSelectedRole(role): void{
    this.selectedRole = role;
  }

  getRoles(){
    this.uService.getAll().subscribe(output =>{
      this.roles = output;
      this.ref.markForCheck()
    })
  }

  editRole(id){
    this.router.navigate(['edit-role/' + id]);
  }

}

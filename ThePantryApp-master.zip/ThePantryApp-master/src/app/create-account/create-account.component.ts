import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef, ViewChild, TemplateRef, ElementRef } from '@angular/core';
import {FormBuilder,FormGroup,Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
import { MustMatch } from './must-match.validator';
import { Observable } from 'rxjs';
import {NgbModal,NgbModalConfig} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CreateAccountComponent implements OnInit {
  @ViewChild('successModal') successModal: TemplateRef < any > ;
  @ViewChild('emailInvalidModal') emailInvalidModal: TemplateRef <any>;
  @ViewChild('confirmPassword') confirmPasswordField: ElementRef;
  @ViewChild('email') emailField: ElementRef;
  registerForm: FormGroup;
  submitted: Boolean = false;
  user: {
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    address: '',
    address2: '',
    city: '',
    state: 'MI',
    zip: '',
    phone: '',
    race: '',
    gender: '',
    employer: '',
    affiliation: '',
    accommodations: '',
    allergy: '',
    emgContactFName: '',
    emgContactLName: '',
    emgContactPhone: '',
    role:'user'

  };
  constructor(private formBuilder: FormBuilder, private userService: UserService, private modal: NgbModal, config: NgbModalConfig, private router: Router) {
    config.backdrop = "static";
    config.keyboard = false;
   }

  ngOnInit() {
    var regexpEmail = new RegExp(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
    this.registerForm = this.formBuilder.group({
      firstName: ['', [Validators.required]],
      lastName: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.pattern(regexpEmail)]],
      password:['', [Validators.required, Validators.minLength(6)]],
      confirmPassword:['', [Validators.required]],
      address: ['', [Validators.required]],
      address2: [''],
      city: ['', [Validators.required]],
      state: ['MI', [Validators.required]],
      zip: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(5)]],
      phone: ['', [Validators.required]],
      race: ['', [Validators.required]],
      gender: ['', [Validators.required]],
      employer: ['', [Validators.required]],
      affiliation: [''],
      accommodations: [''],
      allergy: [''],
      emgContactFName: ['', [Validators.required]],
      emgContactLName: ['', [Validators.required]],
      emgContactPhone: ['', [Validators.required]]

    }, {
      validator: MustMatch('password', 'confirmPassword')
    });

    this.user =  {
      firstName: '',
      lastName: '',
      email: '',
      password:'',
      address: '',
      address2: '',
      city: '',
      state: 'MI',
      zip: '',
      phone: '',
      race: '',
      gender: '',
      employer: '',
      affiliation: '',
      accommodations: '',
      allergy: '',
      emgContactFName: '',
      emgContactLName: '',
      emgContactPhone: '',
      role:'user'
  
    };
  }


  get f() {
    return this.registerForm.controls;
  }
  
  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.registerForm.invalid) {
      if(!this.registerForm.controls.confirmPassword.valid){
        this.confirmPasswordField.nativeElement.focus();
      }
      console.log('invalid')
      return;
    }else{
      this.createUserAccount()
    }

    
  }


  createUserAccount() {
    this.submitted = true;
    // stop here if form is invalid
    if (!this.registerFormCheck()) {

      return;
    } else {
      //create the user in the user database 
      var formHold = this.registerForm.controls;
      this.user.accommodations = formHold.accommodations.value
      this.user.address = formHold.address.value
      this.user.address2 = formHold.address2.value
      this.user.affiliation = formHold.affiliation.value
      this.user.allergy = formHold.allergy.value
      this.user.city = formHold.city.value
      this.user.email = formHold.email.value.toLowerCase()
      this.user.password = formHold.password.value
      this.user.emgContactFName = formHold.emgContactFName.value
      this.user.emgContactLName = formHold.emgContactLName.value
      this.user.emgContactPhone = formHold.emgContactPhone.value
      this.user.employer = formHold.employer.value
      this.user.firstName = formHold.firstName.value
      this.user.gender = formHold.gender.value
      this.user.lastName = formHold.lastName.value
      this.user.phone = formHold.phone.value
      this.user.race = formHold.race.value
      this.user.state = formHold.state.value
      this.user.zip = formHold.zip.value
      this.userService.checkUserEmail(this.user.email).toPromise().then(res =>{
        if(res ==null){
          this.userService.createUser(this.user).toPromise().then(res =>{
            if(res !=null){
              delete res.password
              this.userService.user = res
              this.userService.loggedIn = true;
              localStorage.setItem('usrInfo', res._id)
              this.modal.open(this.successModal, {size: 'lg'})
           }
          }).catch(err=>{
            console.log(err)
          })
        }
        else{
          this.modal.open(this.emailInvalidModal, {size: 'lg'});
          this.emailField.nativeElement.focus();
        }

      }).catch(err=>{
        console.log(err)
      })
      
    }

  }

  registerFormCheck() {
    var formHold = this.registerForm.controls;

    if ( formHold.firstName.valid && formHold.lastName.valid && formHold.email.valid && formHold.phone.valid && formHold.address.valid && formHold.city.valid && formHold.zip.valid && formHold.race.valid && formHold.gender.valid && formHold.employer.valid && formHold.emgContactFName.valid && formHold.emgContactLName.valid && formHold.emgContactPhone.valid){
      return true;
    }
    else{
      return false;
    }
  }


  closeAll() {
    this.modal.dismissAll();
  }

  goTo(_location){
    this.router.navigate([_location]);
    this.modal.dismissAll();
  }


}

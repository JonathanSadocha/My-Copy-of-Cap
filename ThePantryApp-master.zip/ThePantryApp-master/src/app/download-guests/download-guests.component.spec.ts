import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DownloadGuestsComponent } from './download-guests.component';

describe('DownloadGuestsComponent', () => {
  let component: DownloadGuestsComponent;
  let fixture: ComponentFixture<DownloadGuestsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DownloadGuestsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DownloadGuestsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DownloadUsersComponent } from './download-users.component';

describe('DownloadUsersComponent', () => {
  let component: DownloadUsersComponent;
  let fixture: ComponentFixture<DownloadUsersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DownloadUsersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DownloadUsersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { DownloadsService } from '../downloads.service';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';


@Component({
  selector: 'app-download-users',
  templateUrl: './download-users.component.html',
  styleUrls: ['./download-users.component.scss']
})
export class DownloadUsersComponent implements OnInit {

  constructor(private downloadService: DownloadsService, private router: Router, private spinner: NgxSpinnerService) { }

  ngOnInit() {
    this.spinner.show()
    this.downloadService.getUsersExcelFile().subscribe(res=>{
      this.downloadService.getUserExcelFileDownload(res.fileName).subscribe(response => 
        this.downLoadFile(response, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
        setTimeout(() => {
          /** spinner ends after 5 seconds */
          this.spinner.hide();
      }, 5000);
    })
  }


      /**
       * Method is use to download file.
       * @param data - Array Buffer data
       * @param type - type of the document.
       */
      downLoadFile(data: any, type: string) {
          var blob = new Blob([data], { type: type});
          if (window.navigator && window.navigator.msSaveOrOpenBlob) {
            window.navigator.msSaveOrOpenBlob(blob);  
          }
          else {
             var objectUrl = URL.createObjectURL(blob);
              window.open(objectUrl);  
          }

          this.router.navigate(['account'])

      }

}

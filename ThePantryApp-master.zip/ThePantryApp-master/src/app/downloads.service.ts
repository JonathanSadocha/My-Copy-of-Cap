import { Injectable, LOCALE_ID, Inject } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams  } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { headersToString } from 'selenium-webdriver/http';
import { DomSanitizer } from '@angular/platform-browser';

@Injectable({
  providedIn: 'root'
})
export class DownloadsService {
  // apiUrl = 'http://localhost:3333/api/';
  apiUrl = 'http://volunteer.thepantry.gr:3333/'
  constructor(private http: HttpClient, private sanitizer: DomSanitizer) {
    // this.apiUrl = 'http://localhost:3333/'
    this.apiUrl = 'http://volunteer.thepantry.gr:3333/'
  }

  getUserExcelFileDownload(filepath): Observable<any>{
    return this.http.get(this.apiUrl + 'static/data/users/'+filepath,{responseType: 'blob'})
  }
  
  getGuestExcelFileDownload(filepath): Observable<any>{
    return this.http.get(this.apiUrl + 'static/data/guests/'+filepath,{responseType: 'blob'})
  }

  
  getUsersExcelFile(): Observable<any>{
    return this.http.get(this.apiUrl + 'api/user/getExcelFile')
  }

  getGuestExcelFile(): Observable<any>{
    return this.http.get(this.apiUrl + 'api/guest/getExcelFile')
  }
}

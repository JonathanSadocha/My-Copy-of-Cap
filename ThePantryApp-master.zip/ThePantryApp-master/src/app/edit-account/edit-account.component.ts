import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef, ViewChild, TemplateRef, ElementRef, Input } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
import {NgbModal,NgbModalConfig} from '@ng-bootstrap/ng-bootstrap';
import { detectChanges } from '@angular/core/src/render3';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-edit-account',
  templateUrl: './edit-account.component.html',
  styleUrls: ['./edit-account.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class EditAccountComponent implements OnInit {
  @ViewChild('successModal') successModal: TemplateRef<any>;
  userHolder;
  userForm: FormGroup;
  submitted: Boolean = false;

  constructor(private formBuilder: FormBuilder, private userService: UserService, private modal: NgbModal, config: NgbModalConfig, private router: Router, private ref: ChangeDetectorRef) {
    config.backdrop = "static";
    config.keyboard = false;
  }

  ngOnInit(): void {
    var regexpEmail = new RegExp(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);   
    this.userForm = this.formBuilder.group({
      firstName: ['', [Validators.required]],
      lastName: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.pattern(regexpEmail)]],
      address: ['', [Validators.required]],
      address2: [''],
      city: ['', [Validators.required]],
      state: ['', [Validators.required]],
      zip: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(5)]],
      phone: ['', [Validators.required]],
      race: ['', [Validators.required]],
      gender: ['', [Validators.required]],
      employer: ['', [Validators.required]],
      affiliation: [''],
      accommodations: [''],
      allergy: [''],
      emgContactFName: ['', [Validators.required]],
      emgContactLName: ['', [Validators.required]],
      emgContactPhone: ['', [Validators.required]]

    });
    if(localStorage.getItem('usrInfo')!=null){
      this.userService.getSessionUser(localStorage.getItem('usrInfo')).subscribe(res=>{
       this.userHolder = res[0]
       this.userForm = this.formBuilder.group({
         firstName: [res[0].firstName, [Validators.required]],
         lastName: [res[0].lastName, [Validators.required]],
         email: [res[0].email, [Validators.required, Validators.pattern(regexpEmail)]],
         address: [res[0].address, [Validators.required]],
         address2: [res[0].address2],
         city: [res[0].city, [Validators.required]],
         state: [res[0].state, [Validators.required]],
         zip: [res[0].zip, [Validators.required, Validators.minLength(5), Validators.maxLength(5)]],
         phone: [res[0].phone, [Validators.required]],
         race: [res[0].race, [Validators.required]],
         gender: [res[0].gender, [Validators.required]],
         employer: [res[0].employer, [Validators.required]],
         affiliation: [res[0].affiliation],
         accommodations: [res[0].accommodations],
         allergy: [res[0].allergy],
         emgContactFName: [res[0].emgContactFName, [Validators.required]],
         emgContactLName: [res[0].emgContactLName, [Validators.required]],
         emgContactPhone: [res[0].emgContactPhone, [Validators.required]]
   
       });
       //this line is critical, if removed it will not allow for the data to be displayed instantly
       this.ref.markForCheck()
       return this.userHolder = res[0]
     })
   }
   else{
     this.userService.user = {};
     this.userService.loggedIn = false;
   } 
 
   }

   get f() {
    return this.userForm.controls;
  }
  
  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.userForm.invalid) {

      console.log('invalid')
      return;
    }else{
      this.updateUserAccount()
    }
  }

 
 
 
   updateUserAccount(){
     //call the userservice and update the account in here
     var userFormData = this.getFormData();
     this.userService.updateUser(userFormData).subscribe(res=>{
       this.modal.open(this.successModal, {size: 'lg'})
       this.ref.markForCheck();
     })
   }

   goToAccount(){
    this.modal.dismissAll();
    this.router.navigate(['account']);
  }

     //closes all modals
  closeAll() {
    this.modal.dismissAll();
  }

   getFormData(){
     var ctrl = this.userForm.controls;
     var objOut={};
     objOut['_id'] = this.userHolder._id
     objOut['firstName'] = ctrl['firstName'].value;
     objOut['lastName']= ctrl['lastName'].value;
     objOut['email']= ctrl['email'].value;
     objOut['address']= ctrl['address'].value;
     if(ctrl['address2'].value == null){ 
      objOut['address2']= '';
    }else{
       objOut['address2']= ctrl['address2'].value;
    }
     objOut['city']= ctrl['city'].value;
     objOut['state']= ctrl['state'].value;
     objOut['zip']= ctrl['zip'].value;
     objOut['phone']= ctrl['phone'].value;
     objOut['race']= ctrl['race'].value;
     objOut['gender']= ctrl['gender'].value;
     objOut['employer']= ctrl['employer'].value;

     if(ctrl['affiliation'].value == null){
      objOut['affiliation']= ''
    }else{
      objOut['affiliation']= ctrl['affiliation'].value;
     }

     if(ctrl['accommodations'].value == null){
      objOut['accommodations']=''
     }else{
      objOut['accommodations']= ctrl['accommodations'].value;
     }
     if(ctrl['allergy'].value == null){
      objOut['allergy']= '';
     }else{
      objOut['allergy']= ctrl['allergy'].value;
     }
     objOut['emgContactFName']= ctrl['emgContactFName'].value;
     objOut['emgContactLName']= ctrl['emgContactLName'].value;
     objOut['emgContactPhone']= ctrl['emgContactPhone'].value;
     return objOut;


   }

}

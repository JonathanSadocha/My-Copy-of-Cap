import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef, TemplateRef, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import {NgbModal,NgbModalConfig} from '@ng-bootstrap/ng-bootstrap';
import { ActivatedRoute } from '@angular/router';
import { EditRoleService } from '../edit-role.service';
import { Location } from '@angular/common';
import { FormsModule, FormGroup, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-edit-role',
  templateUrl: './edit-role.component.html',
  styleUrls: ['./edit-role.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class EditRoleComponent implements OnInit {
  @ViewChild('successModal') successModal: TemplateRef<any>;
  @ViewChild('deleteModal') deleteModal: TemplateRef<any>;
  urlId: string;
  roleForm: FormGroup;
  submitted;


  constructor(private activateRoute: ActivatedRoute, private editRole: EditRoleService, private ref: ChangeDetectorRef, private formBuilder: FormBuilder, private location: Location, private router: Router, private modal: NgbModal) { 
  
  }

  ngOnInit() {
    this.urlId = this.activateRoute.snapshot.paramMap.get("id")
    this.editRole.getRoleById(this.urlId).subscribe(res=>{
      this.roleForm = this.formBuilder.group({
        role: [res['role'], [Validators.required]],
        time: [res['time'], [Validators.required]],
        qty: [res['qty'], [Validators.required]],
        description: [res['description'], [Validators.required]],
        startDate: [res['startDate'], [Validators.required]],
        endDate: [res['endDate'], [Validators.required]]
  
      });
      this.ref.markForCheck()
    })
  }

  //returning the form builder
  get f(){
    return this.roleForm.controls
  }

  // When submitting the edit roles form, update the data in the database
  onSubmit(){
// *** check how nick did the stuff in create roles, same general idea of putting the controls values into a 
    //temp object then passing it to update role
    // })
    this.submitted = true;
    if (this.roleForm.invalid){
      return;
    }else{
      var ctrl = this.f;
      var objOut = {
        _id: this.urlId,
        role: ctrl['role'].value,
        qty: ctrl['qty'].value,
        time: ctrl['time'].value,
        description: ctrl['description'].value,
        startDate: ctrl['startDate'].value,
        endDate: ctrl['endDate'].value,
        days: {monday:false, tuesday: false, wednesday: false, thursday: false, friday: false, saturday: false}
      }
      this.update(objOut);
    }
  }

  //goes back to the previous page; the roles table
  goBack(){
    this.location.back();
  }

  //passes the current object to the update function in the editservice obj.
  update(obj){
    this.editRole.updateRole(obj).subscribe(res=>{
      this.modal.open(this.successModal, {size: 'lg'})
      this.ref.markForCheck();
    })
  }

  onDelete(){
    if(this.roleForm.invalid){
      return;
    }else{
      this.delete(this.urlId)
      this.goToRoles()
    }
  }

  openDelModal(){
    this.modal.open(this.deleteModal, {size: 'lg'})
  }

  //deletes the current role by passing the object to the editservice obj 
  delete(id){
    this.editRole.deleteRole(id).subscribe(res=>{
      this.ref.markForCheck();
    })
  }

  closeAll() {
    this.modal.dismissAll();
  }

  goToRoles(){
    this.modal.dismissAll();
    this.router.navigate(['roles']);
  }
}

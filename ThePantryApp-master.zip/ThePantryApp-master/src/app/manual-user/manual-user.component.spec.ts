import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManualUserComponent } from './manual-user.component';

describe('ManualUserComponent', () => {
  let component: ManualUserComponent;
  let fixture: ComponentFixture<ManualUserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManualUserComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManualUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

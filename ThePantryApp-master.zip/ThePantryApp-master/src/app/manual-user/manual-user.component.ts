import { Component, OnInit, ChangeDetectionStrategy, ViewChild, TemplateRef, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../user.service';
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';


@Component({
  selector: 'app-manual-user',
  templateUrl: './manual-user.component.html',
  styleUrls: ['./manual-user.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ManualUserComponent implements OnInit {
  @ViewChild('successModal') successModal: TemplateRef < any > ;
  @ViewChild('emailInvalidModal') emailInvalidModal: TemplateRef <any>;
  @ViewChild('confirmPassword') confirmPasswordField: ElementRef;
  @ViewChild('email') emailField: ElementRef;

  registerForm: FormGroup;
  submitted: Boolean = false;
  user: {
    firstName: String,
    lastName: String,
    email: String,
    password: String,
    address: String,
    address2: String,
    city: String,
    state: 'MI',
    zip: String,
    phone: String,
    race: String,
    gender: String,
    employer: String,
    affiliation: String,
    accommodations: String,
    allergy: String,
    emgContactFName: String,
    emgContactLName: String,
    emgContactPhone: String,
    role:'user'

  };
  constructor(private formBuilder: FormBuilder, private userService: UserService, private modal: NgbModal, config: NgbModalConfig, private router: Router) {
    config.backdrop = "static";
    config.keyboard = false;
   }

  ngOnInit() {
    let possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890,./;'[]\=-)(*&^%$#@!~`";
    const lengthOfCode = 40;
    
    var regexpEmail = new RegExp(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
    this.registerForm = this.formBuilder.group({
      firstName: ['', [Validators.required]],
      lastName: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.pattern(regexpEmail)]],
      address: ['', [Validators.required]],
      address2: [''],
      city: ['', [Validators.required]],
      state: ['MI', [Validators.required]],
      zip: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(5)]],
      phone: ['', [Validators.required]],
      race: ['', [Validators.required]],
      gender: ['', [Validators.required]],
      employer: ['', [Validators.required]],
      affiliation: [''],
      accommodations: [''],
      allergy: [''],
      emgContactFName: ['', [Validators.required]],
      emgContactLName: ['', [Validators.required]],
      emgContactPhone: ['', [Validators.required]]

    });
    this.user =  {
      firstName: '',
      lastName: '',
      email: '',
      password:'',
      address: '',
      address2: '',
      city: '',
      state: 'MI',
      zip: '',
      phone: '',
      race: '',
      gender: '',
      employer: '',
      affiliation: '',
      accommodations: '',
      allergy: '',
      emgContactFName: '',
      emgContactLName: '',
      emgContactPhone: '',
      role:'user'
  
    };  
    this.user.password = this.makeRandom(lengthOfCode, possible).toString();

  }


  get f(){
    return this.registerForm.controls
  }

  makeRandom(lengthOfCode: number, possible: string) {
    let text = "";
    for (let i = 0; i < lengthOfCode; i++) {
      text += possible.charAt(Math.floor(Math.random() * possible.length));
    }
      return text;
  }



onSubmit() {
  this.submitted = true;
  // stop here if form is invalid
  if (this.registerForm.invalid) {
    console.log('invalid')
    return;
  }else{
    this.createUserAccount()
  } 
}

createUserAccount(){
  this.assignValues();
  this.userService.checkUserEmail(this.user.email).subscribe(res =>{
    console.log(res)
    if(res ==null){
      this.userService.createManuallyUser(this.user).subscribe(res =>{
        if(res !=null){
          delete res.password
          this.modal.open(this.successModal, {size: 'lg'})
       }
      })
    }
    else{
      this.modal.open(this.emailInvalidModal, {size: 'lg'});
      this.emailField.nativeElement.focus();
    }

  })
}
 
assignValues(){
  var ctrl = this.f;

  this.user.firstName = ctrl['firstName'].value
  this.user.lastName = ctrl['lastName'].value
  this.user.email = ctrl['email'].value
  this.user.address = ctrl['address'].value
  this.user.address2 = ctrl['address2'].value
  this.user.city = ctrl['city'].value
  this.user.zip = ctrl['zip'].value
  this.user.phone = ctrl['phone'].value
  this.user.race = ctrl['race'].value
  this.user.gender = ctrl['gender'].value
  this.user.employer = ctrl['employer'].value
  this.user.affiliation = ctrl['affiliation'].value
  this.user.accommodations = ctrl['accommodations'].value
  this.user.allergy = ctrl['allergy'].value
  this.user.emgContactFName = ctrl['emgContactFName'].value
  this.user.emgContactLName = ctrl['emgContactLName'].value
  this.user.emgContactPhone = ctrl['emgContactPhone'].value
  return this.user
  
}


closeAll() {
  this.modal.dismissAll();
}

}

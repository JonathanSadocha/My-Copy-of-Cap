import { Component, OnInit, ViewChild, TemplateRef, ElementRef, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../user.service';
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit {

  @ViewChild('successModal') successModal: TemplateRef < any > ;
  @ViewChild('invalidToken') invalidToken: TemplateRef < any > ;
  @ViewChild('confirmPassword') confirmPasswordField: ElementRef;
  submitted: Boolean = false;
  resetForm: FormGroup;
  constructor(private route: ActivatedRoute, private userService: UserService, private router: Router, private ref: ChangeDetectorRef,private modal: NgbModal, config: NgbModalConfig, private formBuilder: FormBuilder) { 
    config.backdrop = "static";
    config.keyboard = false;
  }

  ngOnInit() {
    var regexpEmail = new RegExp(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/);
    this.resetForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.pattern(regexpEmail)]]
    })
  }


  get f(){
    return this.resetForm.controls
  }

  onSubmit(){
    this.submitted = true;
    // stop here if form is invalid
    if (this.resetForm.invalid) {

      console.log('invalid')
      return;
    }else{
      this.userService.resetPassword(this.resetForm.controls['email'].value).subscribe(res=>{
        if(res == null){

        }else if(res == 'success'){
          this.modal.open(this.successModal, {size: 'lg'})
        }
        else{
          console.log('an error has occured')
        }
      })
    }
  }


  
  closeAll() {
    this.modal.dismissAll();
  }

  goTo(_location){
    this.router.navigate([_location]);
    this.modal.dismissAll();
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SpecialEventEditComponent } from './special-event-edit.component';

describe('SpecialEventEditComponent', () => {
  let component: SpecialEventEditComponent;
  let fixture: ComponentFixture<SpecialEventEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SpecialEventEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpecialEventEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

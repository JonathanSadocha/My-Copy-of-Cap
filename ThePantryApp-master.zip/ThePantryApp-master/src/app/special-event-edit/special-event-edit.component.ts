import { Component, OnInit, ChangeDetectorRef, TemplateRef, ViewChild, ChangeDetectionStrategy } from '@angular/core';
import { SpecialEventsService } from '../special-events.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-special-event-edit',
  templateUrl: './special-event-edit.component.html',
  styleUrls: ['./special-event-edit.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SpecialEventEditComponent implements OnInit {
  @ViewChild('successModal') successModal: TemplateRef < any > ;

  submitted: Boolean = false;
  editSpecialEventsForm: FormGroup;
  item;
  param1: String;

  constructor( private sEventService: SpecialEventsService,private actRoute: ActivatedRoute, private ref: ChangeDetectorRef, private config: NgbModalConfig, private formBuilder: FormBuilder, private router: Router, private modal: NgbModal ) { 
    config.backdrop = "static";
    config.keyboard = false;
  }

  ngOnInit() {
    this.param1 = this.actRoute.snapshot.paramMap.get("id")
    this.editSpecialEventsForm = this.formBuilder.group({
      title: ['', [Validators.required]],
      description: ['', [Validators.required]],
      volunteersNeeded: [, [Validators.required]],
      volunteers: [[], [Validators.required]],
      startTime: [new Date(), [Validators.required]],
      endTime: [new Date(), [Validators.required]],
      startDate: [new Date(), [Validators.required]],
      endDate: [new Date(), [Validators.required]]
    });
    this.getOneEvent(this.param1)
  }

  
  getOneEvent(id){
    this.sEventService.getSpecialEvent(id).subscribe(res=>{  
      this.editSpecialEventsForm.setValue({
        title: res['title'], 
        description: res['description'],
        volunteersNeeded: res['volunteersNeeded'],
        volunteers: [res['volunteers']],
        startTime: res['startTime'],
        endTime: res['endTime'], 
        startDate: res['startDate'],
        endDate: res['startDate'],
       });
       this.item = res
      this.ref.markForCheck()
    })
  }
  get f(){
    return this.editSpecialEventsForm.controls
  }


  onSubmitUpdate(){
    this.submitted = true;
    if (this.editSpecialEventsForm.invalid) {
      return;
    }else{
      var ctrl = this.f;
      var objOut = {
        _id: this.item['_id'],
        title: ctrl['title'].value,
        description: ctrl['description'].value,
        volunteersNeeded: ctrl['volunteersNeeded'].value,
        volunteers: this.item['_id'],
        startTime: ctrl['startTime'].value,
        endTime: ctrl['endTime'].value,
        startDate: ctrl['startDate'].value,
        endDate: ctrl['endDate'].value,
      }
      this.ref.markForCheck()
      this.update( objOut);
    }
  }



  
  update( obj){
    this.sEventService.updateSpecialEvent( obj).subscribe(res=>{
      if(res){
        this.modal.open(this.successModal, {size: 'lg'})
      }
    })  
  }

  goToSE(){
    this.router.navigate(['/special-events'])
    this.modal.dismissAll()
  }


}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SpecialEventNewComponent } from './special-event-new.component';

describe('SpecialEventNewComponent', () => {
  let component: SpecialEventNewComponent;
  let fixture: ComponentFixture<SpecialEventNewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SpecialEventNewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SpecialEventNewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit, ChangeDetectorRef, TemplateRef, ViewChild } from '@angular/core';
import { SpecialEventsService } from '../special-events.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-special-event-new',
  templateUrl: './special-event-new.component.html',
  styleUrls: ['./special-event-new.component.scss']
})
export class SpecialEventNewComponent implements OnInit {
  @ViewChild('successModal') successModal: TemplateRef < any > ;

  submitted: Boolean = false;
  addSpecialEventsForm: FormGroup;
  item;

  constructor( private sEventService: SpecialEventsService,private actRoute: ActivatedRoute, private ref: ChangeDetectorRef, private config: NgbModalConfig, private formBuilder: FormBuilder, private router: Router, private modal: NgbModal ) { 
    config.backdrop = "static";
    config.keyboard = false;
  }


  ngOnInit() {
    this.addSpecialEventsForm = this.formBuilder.group({
      title: ['', [Validators.required]],
      description: ['', [Validators.required]],
      volunteersNeeded: [Number, [Validators.required]],
      volunteers: [[]],
      startTime: [new Date()],
      endTime:[new Date()],
      startDate: [new Date()],
      endDate: [new Date()]
    });
    this.ref.markForCheck()
  }

  onSubmitNew() {
    this.submitted = true;
    if (this.addSpecialEventsForm.invalid) {
      return;
    }else{
      var ctrl = this.f;
      var objOut = {
        title: ctrl['title'].value,
        description: ctrl['description'].value,
        volunteersNeeded: ctrl['volunteersNeeded'].value,
        volunteers: [ctrl['volunteers'].value],
        startTime: ctrl['startTime'].value,
        endTime: ctrl['endTime'].value,
        startDate: ctrl['startDate'].value,
        endDate: ctrl['endDate'].value,
      }
      this.ref.markForCheck()
      this.createEvent(objOut);
    }
  }

  get f(){
    return this.addSpecialEventsForm.controls
  }


  createEvent(obj){
    this.sEventService.createSpecialEvent(obj).subscribe(res=>{
      if(res){
        this.modal.open(this.successModal, {size: 'lg'})
      }
    })
  }

  
  goToSE(){
    this.router.navigate(['/special-events'])
    this.modal.dismissAll()
  }
}

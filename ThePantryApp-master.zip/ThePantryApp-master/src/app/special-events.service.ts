import {Injectable, LOCALE_ID, Inject} from '@angular/core';
import {DatePipe} from '@angular/common';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'node_modules/rxjs';
import {Location} from '@angular/common'
import { NavigationEnd, Router } from 'node_modules/@angular/router';
import * as moment from 'moment';
@Injectable({
  providedIn: 'root'
})
export class SpecialEventsService {

  rangeDates: Array<any> = [];
  eventItems = Array();
  eventTest: Observable<any>;
  user: Object;
  loggedIn: Boolean = false;
  // apiUrl = 'http://localhost:3333/api/';
  apiUrl = 'http://volunteer.thepantry.gr:3333/api/'


  constructor(private http: HttpClient, private location: Location, router: Router, @Inject(LOCALE_ID) private locale: string) {
    // this.apiUrl = 'http://localhost:3333/api/'
    this.apiUrl = 'http://volunteer.thepantry.gr:3333/api/'

  }

  createSpecialEvent(event):Observable<any>{
      return this.http.post(this.apiUrl+'specialEvent/create', event)
  }

  getAll():Observable<any>{
    return this.http.get(this.apiUrl+'specialEvent/getAll')
  }
  
  deleteSpecialEvent(id):Observable<any>{
    return this.http.delete(this.apiUrl+'specialEvent/delete/'+ id, id)
  }
  
  updateSpecialEvent( event):Observable<any>{
    return this.http.post(this.apiUrl+'specialEvent/update', event)
  }

  getSpecialEvent(id):Observable<any>{
    return this.http.get(this.apiUrl+'specialEvent/get/'+ id,)
  }

}

import { Component, OnInit, TemplateRef, ViewChild  } from '@angular/core';
import { Router } from '@angular/router';
import {NgbModal,NgbModalConfig} from '@ng-bootstrap/ng-bootstrap';
import { CalendarService } from '../calendar/calendar.service';
import { CalendarComponent } from '../calendar/calendar.component';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { SpecialEventsService } from '../special-events.service';
import {MatDatepickerModule,} from '@angular/material';
import { ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Location } from '@angular/common';
import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Template } from '@angular/compiler/src/render3/r3_ast';


@Component({
  selector: 'app-change-events',
  templateUrl: './special-events.component.html',
  styleUrls: ['./special-events.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SpecialEventsComponent implements OnInit {
  @ViewChild('editModal') editModal: TemplateRef<any>;
  @ViewChild('deleteModal') deleteModal: TemplateRef<any>;
  @ViewChild('createNewModal') createNewModal: TemplateRef<any>;
  @ViewChild('successModal') deleteSuccess: TemplateRef<any>
  events;
  modalRef: BsModalRef;
  modalReference;
  bsValue = new Date();
  minDate: Date;
  maxDate: Date;
  selectedEvent;
  addSpecialEventsForm: FormGroup;
  editSpecialEventsForm: FormGroup;
  submitted;
  storedId: string;
  item:{
    title: String,
    description: String,
    volunteersNeeded: Number,
    volunteers: Array<String>,
    startTime:Date,
    endTime: Date,
    startDate: Date,
    endDate: Date,
  }

  eventNew: {
    title: String,
    description: String,
    volunteersNeeded: Number,
    volunteers: [],
    startTime:Date,
    endTime: Date,
    startDate: Date,
    endDate: Date,
  }

  constructor( private modalService: BsModalService, private sEventService: SpecialEventsService, private ref: ChangeDetectorRef, private formBuilder: FormBuilder, private router: Router, private modal: NgbModal) {
    this.minDate = new Date();
    this.maxDate = new Date();
    this.minDate.setDate(this.minDate.getDate() - 1);
    this.maxDate.setDate(this.maxDate.getDate() + 365);
   }

  ngOnInit() {
    this.events = [];
    this.getEvents();
    this.addSpecialEventsForm = this.formBuilder.group({
      title: ['', [Validators.required]],
      description: ['', [Validators.required]],
      volunteersNeeded: [, [Validators.required]],
      volunteers: [[], [Validators.required]],
      startTime: [new Date(), [Validators.required]],
      endTime:[new Date(), [Validators.required]],
      startDate: [new Date(), [Validators.required]],
      endDate: [new Date(), [Validators.required]]
    });
    this.ref.markForCheck()

    // this.urlId = this.activateRoute.snapshot.paramMap.get("id")
    this.editSpecialEventsForm = this.formBuilder.group({
      titleup: ['', [Validators.required]],
      descriptionup: ['', [Validators.required]],
      volunteersNeededup: [, [Validators.required]],
      volunteers: [[], [Validators.required]],
      startTime: [new Date(), [Validators.required]],
      endTime: [new Date(), [Validators.required]],
      startDate: [new Date(), [Validators.required]],
      endDate: [new Date(), [Validators.required]]
    });
    this.ref.markForCheck()
  }

  getSelectedRole(role): void{
    this.selectedEvent = role;
  }

  getEvents(): void{
    this.sEventService.getAll().subscribe(output=>{
      this.events = output;
      this.ref.markForCheck()
    })
  }

  editSE(id){
    this.router.navigate(['/special-events/edit/'+id])
  }


  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }


  delete(id){
    this.sEventService.deleteSpecialEvent(id).subscribe(res=>{
      if(res == 'success'){
        this.modal.open(this.deleteSuccess, {size: 'lg'})
      }
    })
  }

  get f(){
    return this.addSpecialEventsForm.controls
  }

  onSubmitDelete() {
    this.delete(this.storedId)
    this.storedId = ''
  }
  storeId(id){
    this.storedId = id
  }

  closeAll() {
    this.modal.dismissAll();
  }

  openDelModal(){
    this.modal.open(this.deleteModal, {size: 'lg'})
}

goToSE(){
  this.getEvents()
  this.router.navigate(['/special-events'])
  this.modal.dismissAll()
}

}

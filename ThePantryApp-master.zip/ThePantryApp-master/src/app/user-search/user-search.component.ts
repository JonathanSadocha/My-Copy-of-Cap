import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { UserService } from '../user.service';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';


@Component({
  selector: 'app-user-search',
  templateUrl: './user-search.component.html',
  styleUrls: ['./user-search.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UserSearchComponent implements OnInit {
  users: Observable<Object[]>
  constructor(private userService: UserService, private ref: ChangeDetectorRef, private router: Router) { }

  ngOnInit() {
    //get the users collection and and the guests collection here
    this.userService.getAllUsers().subscribe(res=>{
      this.users = res;
      this.ref.markForCheck()

    })
  }

  editUser(id){
    this.router.navigate(['/users/edit/'+id])
  }

}
